-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : bibi_y1778_top
-- 
-- Part : #1
-- Date : 2022-02-11 12:33:17
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `danmaku_ip`
-- -----------------------------
DROP TABLE IF EXISTS `danmaku_ip`;
CREATE TABLE `danmaku_ip` (
  `ip` varchar(12) NOT NULL COMMENT '发送弹幕的IP地址',
  `c` int(1) NOT NULL DEFAULT '1' COMMENT '规定时间内的发送次数',
  `time` int(10) NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `danmaku_list`
-- -----------------------------
DROP TABLE IF EXISTS `danmaku_list`;
CREATE TABLE `danmaku_list` (
  `id` varchar(32) NOT NULL COMMENT '弹幕池id',
  `cid` int(8) NOT NULL AUTO_INCREMENT COMMENT '弹幕id',
  `type` varchar(128) NOT NULL COMMENT '弹幕类型',
  `text` varchar(128) NOT NULL COMMENT '弹幕内容',
  `color` varchar(128) NOT NULL COMMENT '弹幕颜色',
  `size` varchar(128) NOT NULL COMMENT '弹幕大小',
  `videotime` float(24,3) NOT NULL COMMENT '时间点',
  `ip` varchar(128) NOT NULL COMMENT '用户ip',
  `time` int(10) NOT NULL COMMENT '发送时间',
  `referer` text NOT NULL COMMENT '弹幕来源网址',
  PRIMARY KEY (`cid`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `danmaku_report`
-- -----------------------------
DROP TABLE IF EXISTS `danmaku_report`;
CREATE TABLE `danmaku_report` (
  `cid` int(8) NOT NULL COMMENT '弹幕ID',
  `id` varchar(128) NOT NULL COMMENT '弹幕池id',
  `text` varchar(128) NOT NULL COMMENT '举报内容',
  `type` varchar(128) NOT NULL COMMENT '举报类型',
  `time` varchar(128) NOT NULL COMMENT '举报时间',
  `ip` varchar(12) NOT NULL COMMENT '发送弹幕的IP地址',
  `referer` text NOT NULL COMMENT '弹幕来源网址',
  PRIMARY KEY (`text`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_actor`
-- -----------------------------
DROP TABLE IF EXISTS `mac_actor`;
CREATE TABLE `mac_actor` (
  `actor_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actor_name` varchar(255) NOT NULL DEFAULT '',
  `actor_en` varchar(255) NOT NULL DEFAULT '',
  `actor_alias` varchar(255) NOT NULL DEFAULT '',
  `actor_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_letter` char(1) NOT NULL DEFAULT '',
  `actor_sex` char(1) NOT NULL DEFAULT '',
  `actor_color` varchar(6) NOT NULL DEFAULT '',
  `actor_pic` varchar(255) NOT NULL DEFAULT '',
  `actor_blurb` varchar(255) NOT NULL DEFAULT '',
  `actor_remarks` varchar(100) NOT NULL DEFAULT '',
  `actor_area` varchar(20) NOT NULL DEFAULT '',
  `actor_height` varchar(10) NOT NULL DEFAULT '',
  `actor_weight` varchar(10) NOT NULL DEFAULT '',
  `actor_birthday` varchar(10) NOT NULL DEFAULT '',
  `actor_birtharea` varchar(20) NOT NULL DEFAULT '',
  `actor_blood` varchar(10) NOT NULL DEFAULT '',
  `actor_starsign` varchar(10) NOT NULL DEFAULT '',
  `actor_school` varchar(20) NOT NULL DEFAULT '',
  `actor_works` varchar(255) NOT NULL DEFAULT '',
  `actor_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_time` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `actor_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `actor_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_tpl` varchar(30) NOT NULL DEFAULT '',
  `actor_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `actor_content` text NOT NULL,
  `type_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type_id_1` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_tag` varchar(255) NOT NULL DEFAULT '',
  `actor_class` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`actor_id`) USING BTREE,
  KEY `actor_name` (`actor_name`) USING BTREE,
  KEY `actor_en` (`actor_en`) USING BTREE,
  KEY `actor_letter` (`actor_letter`) USING BTREE,
  KEY `actor_level` (`actor_level`) USING BTREE,
  KEY `actor_time` (`actor_time`) USING BTREE,
  KEY `actor_time_add` (`actor_time_add`) USING BTREE,
  KEY `actor_sex` (`actor_sex`) USING BTREE,
  KEY `actor_area` (`actor_area`) USING BTREE,
  KEY `actor_up` (`actor_up`) USING BTREE,
  KEY `actor_down` (`actor_down`) USING BTREE,
  KEY `actor_score` (`actor_score`) USING BTREE,
  KEY `actor_score_all` (`actor_score_all`) USING BTREE,
  KEY `actor_score_num` (`actor_score_num`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_adtype`
-- -----------------------------
DROP TABLE IF EXISTS `mac_adtype`;
CREATE TABLE `mac_adtype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typename` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '类别名称',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：1-正常；0：禁用',
  `sort` int(11) NOT NULL DEFAULT '50' COMMENT '排序',
  `tag` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '广告位标识',
  `description` varchar(2000) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='APP广告管理';

-- -----------------------------
-- Records of `mac_adtype`
-- -----------------------------
INSERT INTO `mac_adtype` VALUES ('52', '中心', '0', '0', 'user_center', 'http://img.isryun.com/images/2020/06/28/a6187fd4ed32ace554adbb81dbff1bbd.png', '1560965440', '1593330630');
INSERT INTO `mac_adtype` VALUES ('53', '搜索页广告位', '0', '0', 'searcher', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"http://img.isryun.com/images/2020/07/19/123.png\" width=\"100%\" height=\"100%\" border=\"0\" /></a>', '1560965460', '1595157884');
INSERT INTO `mac_adtype` VALUES ('54', '播放器暂停广告', '0', '0', 'player_pause', '<a href=\"http://www.shouzhuanmao.com/\" target=\"_blank\"><img src=\"http://318hb.cn/bb.png\" width=\"240px\" height=\"200px\" border=\"0\" /></a>', '1560965485', '1572960349');
INSERT INTO `mac_adtype` VALUES ('55', '播放器下方广告', '0', '0', 'player_down', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"https://storage.taifutj.com/admin/202001300958775new.jpg\" width=\"100%\" height=\"100%\" border=\"0\" /></a>', '1560965505', '1584348125');
INSERT INTO `mac_adtype` VALUES ('56', '综艺广告位', '0', '0', 'variety', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"https://1.s91i.faiusr.com/4/AFsIkK06EAQYACCq_NbhBSiru6MaMIAPONgE!800x800.png?v=1574305665030\" width=\"100%\" height=\"100%\" border=\"0\" /></a>', '1560965569', '1583861143');
INSERT INTO `mac_adtype` VALUES ('57', '动漫广告位', '0', '0', 'cartoon', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"https://1.s91i.faiusr.com/4/AFsI55yJARAEGAAg54XU7gUoqL6j0QEwgA842AQ!450x450.png.webp?_tm=3&v=1576442735\" width=\"100%\" height=\"100%\" border=\"0\" /></a>', '1560965583', '1583861131');
INSERT INTO `mac_adtype` VALUES ('58', '连续剧广告位', '0', '0', 'sitcom', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"https://1.s91i.faiusr.com/4/AFsIgKhEEAQYACDf-5fhBSjc1Z38AzCADzjYBA!800x800.png?v=1565323534421\" width=\"100%\" height=\"100%\" border=\"0\" /></a>', '1560965601', '1583861119');
INSERT INTO `mac_adtype` VALUES ('59', '电影广告位', '0', '0', 'vod', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"https://1.s91i.faiusr.com/4/AFsI55yJARAEGAAg9vzT7gUowPD8gAQwgA842AQ!800x800.png?v=1574239862933\" width=\"100%\" height=\"100%\" border=\"0\" /></a>', '1560965614', '1583861103');
INSERT INTO `mac_adtype` VALUES ('60', '首页广告位', '0', '0', 'index', '<a href=\"http://www.baidu.com/\" target=\"_blank\"><img src=\"https://storage.taifutj.com/admin/202001300958775new.jpg\" width=\"100%\" height=\"100%\" border=\"0\" /></a> ', '1560965629', '1584348142');
INSERT INTO `mac_adtype` VALUES ('61', '启动页广告位', '1', '0', 'csj_startup_adv', '10336', '1560965647', '1644472794');
INSERT INTO `mac_adtype` VALUES ('70', '一键登录', '1', '0', 'define_account', '0', '1643361542', '1643712221');
INSERT INTO `mac_adtype` VALUES ('62', 'QQ客服', '1', '0', 'service_qq', '79581008', '1560965677', '1644327900');
INSERT INTO `mac_adtype` VALUES ('66', '会员下载', '1', '63', 'download', '', '1619417774', '0');
INSERT INTO `mac_adtype` VALUES ('67', '会员画中画', '1', '201', 'pictureinpicture', '', '1619417892', '1643367156');
INSERT INTO `mac_adtype` VALUES ('68', '会员投屏', '1', '200', 'projection', '', '1619417925', '1643367141');
INSERT INTO `mac_adtype` VALUES ('71', '一键加群', '0', '0', 'service_qqqun', 'https://jq.qq.com/?_wv=1027&k=B7tHQZmG', '1643366902', '1644246360');
INSERT INTO `mac_adtype` VALUES ('72', '信息流', '1', '0', 'csj_video8_adv', '10338', '1643366976', '1644472782');
INSERT INTO `mac_adtype` VALUES ('73', '激励视频', '1', '0', 'csj_video_adv', '10339', '1643367007', '1644413860');
INSERT INTO `mac_adtype` VALUES ('74', '插屏广告', '1', '0', 'csj_video2_adv', '10337', '1643367041', '1644472772');
INSERT INTO `mac_adtype` VALUES ('75', '全屏广告', '1', '0', 'csj_index3_adv', '10340', '1643367074', '1644472759');
INSERT INTO `mac_adtype` VALUES ('76', '激励次数', '1', '0', 'Number_of_awards', '15', '1643367121', '1644381003');
INSERT INTO `mac_adtype` VALUES ('79', '全屏广告', '0', '0', 'startup_adv', '<a href=\"\" target=\"_blank\"><img src=\"http://inews.gtimg.com/newsapp_ls/0/14482893411/0\" width=\"100%\" height=\"100%\" border=\"0\" /></a>	', '1643719971', '1643719996');

-- -----------------------------
-- Table structure for `mac_annex`
-- -----------------------------
DROP TABLE IF EXISTS `mac_annex`;
CREATE TABLE `mac_annex` (
  `annex_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `annex_time` int(10) unsigned NOT NULL DEFAULT '0',
  `annex_file` varchar(255) NOT NULL DEFAULT '',
  `annex_size` int(10) unsigned NOT NULL DEFAULT '0',
  `annex_type` varchar(8) NOT NULL DEFAULT '',
  PRIMARY KEY (`annex_id`),
  KEY `annex_time` (`annex_time`),
  KEY `annex_file` (`annex_file`),
  KEY `annex_type` (`annex_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_app_install_record`
-- -----------------------------
DROP TABLE IF EXISTS `mac_app_install_record`;
CREATE TABLE `mac_app_install_record` (
  `app_install_record_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_ip` varchar(255) NOT NULL DEFAULT '',
  `invite_user_id` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `is_pull` int(255) NOT NULL DEFAULT '0',
  `extra` varchar(255) NOT NULL DEFAULT '',
  `os` varchar(255) NOT NULL DEFAULT '',
  `os_version` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`app_install_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_app_install_record`
-- -----------------------------
INSERT INTO `mac_app_install_record` VALUES ('1', '127.0.0.1', '0', '1563962961', '1563962961', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('2', '127.0.0.1', '0', '1563962976', '1563962976', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('3', '127.0.0.1', '0', '1563963052', '1563963052', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('4', '127.0.0.1', '0', '1563963081', '1563963081', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('5', '127.0.0.1', '0', '1563963098', '1563963098', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('6', '127.0.0.1', '0', '1563963247', '1563963247', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('7', '127.0.0.1', '1', '1563963275', '1563963275', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('8', '127.0.0.1', '1', '1563963742', '1563963742', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('9', '127.0.0.1', '1', '1563963749', '1563963749', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('10', '127.0.0.1', '1', '1563963764', '1563963764', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('11', '127.0.0.1', '2', '1563963772', '1563963772', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('12', '127.0.0.1', '0', '1563963835', '1563963835', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('13', '127.0.0.1', '0', '1563964604', '1563964604', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('14', '127.0.0.1', '2', '1563965254', '1563965254', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('15', '127.0.0.1', '2', '1563965258', '1563965258', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('16', '127.0.0.1', '2', '1563965261', '1563965261', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('17', '127.0.0.1', '0', '1563971571', '1563971571', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('18', '127.0.0.1', '0', '1563971572', '1563971572', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('19', '127.0.0.1', '0', '1563971572', '1563971572', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('20', '127.0.0.1', '0', '1563971573', '1563971573', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('21', '127.0.0.1', '0', '1563971573', '1563971573', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('22', '127.0.0.1', '0', '1563971573', '1563971573', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('23', '127.0.0.1', '0', '1563971574', '1563971574', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('24', '127.0.0.1', '2', '1563971575', '1563971575', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('25', '127.0.0.1', '0', '1563971602', '1563971602', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('26', '127.0.0.1', '0', '1563971604', '1563971604', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('27', '127.0.0.1', '2', '1563971613', '1563971613', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('28', '127.0.0.1', '0', '1563971617', '1563971617', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('29', '127.0.0.1', '1', '1563971619', '1563971619', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('30', '127.0.0.1', '0', '1563971623', '1563971623', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('31', '127.0.0.1', '1', '1563971626', '1563971626', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('32', '127.0.0.1', '0', '1563971629', '1563971629', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('33', '127.0.0.1', '1', '1563971633', '1563971633', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('34', '127.0.0.1', '0', '1563971636', '1563971636', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('35', '127.0.0.1', '0', '1563971639', '1563971639', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('36', '127.0.0.1', '0', '1563971644', '1563971644', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('37', '127.0.0.1', '0', '1563973045', '1563973045', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('38', '127.0.0.1', '2', '1563974089', '1563974089', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('39', '113.251.131.59', '0', '1569165455', '1569165455', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('40', '122.233.111.115', '30', '1569567032', '1569567032', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('41', '113.251.129.170', '0', '1570023922', '1570023922', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('42', '113.251.129.170', '0', '1570023925', '1570023925', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('43', '113.251.130.131', '0', '1570666954', '1570666954', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('44', '113.251.130.131', '0', '1570666959', '1570666959', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('45', '223.104.249.240', '0', '1570671888', '1570671888', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('46', '113.251.135.229', '2147483647', '1570892020', '1570892020', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('47', '113.251.135.229', '2147483647', '1570892060', '1570892060', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('48', '220.177.71.78', '0', '1571320795', '1571320795', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('49', '117.136.30.43', '0', '1572336698', '1572336698', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('50', '117.136.30.43', '0', '1572336830', '1572336830', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('51', '116.50.143.142', '0', '1572866714', '1572866714', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('52', '223.104.249.156', '2147483647', '1573018038', '1573018038', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('53', '103.90.82.100', '0', '1574961265', '1574961265', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('54', '103.90.82.100', '0', '1574961266', '1574961266', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('55', '103.90.82.100', '0', '1574961277', '1574961277', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('56', '123.160.227.1', '0', '1574996724', '1574996724', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('57', '123.160.227.1', '0', '1574996727', '1574996727', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('58', '58.247.212.239', '0', '1575083559', '1575083559', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('59', '123.53.32.86', '0', '1575101709', '1575101709', '0', '', '', '');
INSERT INTO `mac_app_install_record` VALUES ('60', '220.177.70.40', '0', '1588499649', '1588499649', '0', '', '', '');

-- -----------------------------
-- Table structure for `mac_app_version`
-- -----------------------------
DROP TABLE IF EXISTS `mac_app_version`;
CREATE TABLE `mac_app_version` (
  `app_version_id` int(11) NOT NULL AUTO_INCREMENT,
  `os` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `url2` varchar(255) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `is_required` int(11) NOT NULL,
  `type` int(255) DEFAULT '1',
  PRIMARY KEY (`app_version_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='APP更新';


-- -----------------------------
-- Table structure for `mac_art`
-- -----------------------------
DROP TABLE IF EXISTS `mac_art`;
CREATE TABLE `mac_art` (
  `art_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_id_1` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_name` varchar(255) NOT NULL DEFAULT '',
  `art_sub` varchar(255) NOT NULL DEFAULT '',
  `art_en` varchar(255) NOT NULL DEFAULT '',
  `art_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_letter` char(1) NOT NULL DEFAULT '',
  `art_color` varchar(6) NOT NULL DEFAULT '',
  `art_from` varchar(30) NOT NULL DEFAULT '',
  `art_author` varchar(30) NOT NULL DEFAULT '',
  `art_tag` varchar(100) NOT NULL DEFAULT '',
  `art_class` varchar(255) NOT NULL DEFAULT '',
  `art_pic` varchar(255) NOT NULL DEFAULT '',
  `art_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `art_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `art_blurb` varchar(255) NOT NULL DEFAULT '',
  `art_remarks` varchar(100) NOT NULL DEFAULT '',
  `art_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `art_tpl` varchar(30) NOT NULL DEFAULT '',
  `art_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_points_detail` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_time` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `art_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `art_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `art_rel_art` varchar(255) NOT NULL DEFAULT '',
  `art_rel_vod` varchar(255) NOT NULL DEFAULT '',
  `art_pwd` varchar(10) NOT NULL DEFAULT '',
  `art_pwd_url` varchar(255) NOT NULL DEFAULT '',
  `art_title` mediumtext NOT NULL,
  `art_note` mediumtext NOT NULL,
  `art_content` mediumtext NOT NULL,
  `art_pic_screenshot` text,
  PRIMARY KEY (`art_id`) USING BTREE,
  KEY `type_id` (`type_id`) USING BTREE,
  KEY `type_id_1` (`type_id_1`) USING BTREE,
  KEY `art_level` (`art_level`) USING BTREE,
  KEY `art_hits` (`art_hits`) USING BTREE,
  KEY `art_time` (`art_time`) USING BTREE,
  KEY `art_letter` (`art_letter`) USING BTREE,
  KEY `art_down` (`art_down`) USING BTREE,
  KEY `art_up` (`art_up`) USING BTREE,
  KEY `art_tag` (`art_tag`) USING BTREE,
  KEY `art_name` (`art_name`) USING BTREE,
  KEY `art_enname` (`art_en`) USING BTREE,
  KEY `art_hits_day` (`art_hits_day`) USING BTREE,
  KEY `art_hits_week` (`art_hits_week`) USING BTREE,
  KEY `art_hits_month` (`art_hits_month`) USING BTREE,
  KEY `art_time_add` (`art_time_add`) USING BTREE,
  KEY `art_time_make` (`art_time_make`) USING BTREE,
  KEY `art_lock` (`art_lock`) USING BTREE,
  KEY `art_score` (`art_score`) USING BTREE,
  KEY `art_score_all` (`art_score_all`) USING BTREE,
  KEY `art_score_num` (`art_score_num`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_card`
-- -----------------------------
DROP TABLE IF EXISTS `mac_card`;
CREATE TABLE `mac_card` (
  `card_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `card_no` varchar(16) NOT NULL DEFAULT '',
  `card_pwd` varchar(8) NOT NULL DEFAULT '',
  `card_money` smallint(6) unsigned NOT NULL DEFAULT '0',
  `card_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `card_use_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `card_sale_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `card_add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `card_use_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`card_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `card_add_time` (`card_add_time`) USING BTREE,
  KEY `card_use_time` (`card_use_time`) USING BTREE,
  KEY `card_no` (`card_no`) USING BTREE,
  KEY `card_pwd` (`card_pwd`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `mac_card`
-- -----------------------------
INSERT INTO `mac_card` VALUES ('5', 'Q0ZGL6JVE6N32HHF', 'TI98FM7B', '0', '89', '1', '1', '113', '1619757763', '1619761934');
INSERT INTO `mac_card` VALUES ('7', '7EN3LICGCKJX03P9', 'F46O20N9', '0', '89', '1', '1', '87', '1619757763', '1619759303');
INSERT INTO `mac_card` VALUES ('13', 'J2X873USAHM67DHU', 'GNAAYXYQ', '0', '89', '1', '1', '112', '1619757763', '1619759572');

-- -----------------------------
-- Table structure for `mac_cash`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cash`;
CREATE TABLE `mac_cash` (
  `cash_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cash_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cash_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cash_money` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `cash_bank_name` varchar(60) NOT NULL DEFAULT '',
  `cash_bank_no` varchar(30) NOT NULL DEFAULT '',
  `cash_payee_name` varchar(30) NOT NULL DEFAULT '',
  `cash_time` int(10) unsigned NOT NULL DEFAULT '0',
  `cash_time_audit` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cash_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `cash_status` (`cash_status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_category`
-- -----------------------------
DROP TABLE IF EXISTS `mac_category`;
CREATE TABLE `mac_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(60) NOT NULL COMMENT '分类名',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父类id',
  `void_id` text NOT NULL COMMENT '电影id',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否开启：0：否；1：开启',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='APP栏目分类';

-- -----------------------------
-- Records of `mac_category`
-- -----------------------------
INSERT INTO `mac_category` VALUES ('1', '电影抢先看', '1', '113199,113198,113193,113192,113191,113190,113189,113188,113187,113186,113185,98785,98784,98783,89532,89514,88552,87972,86424,86058,113231,113229,98502,113266,113265,113264,113263,113262,113261,113260,113259,110251,97895,91138,113258,113256,113255,113249,113248,113247,113246,113245,110279,113243,65295,113239,113238,113237,113236,113235,113234,113211,113210,113209,113165,113164,113093,113092,113091,113090', '1', '0', '1577729705', '1609446669');
INSERT INTO `mac_category` VALUES ('2', '追剧乐翻天', '2', '113178,113177,113176,111347,108138,106489,108105,104393,73148,56748,56607,47662,579,113199,113198,113193,113192,113191,113190,113189,113188,113187,113186,113185,113184,113183,113182,113181,113180,113179,112935,112934,111074,98785,98784,98783,89532,89514,88552,88515', '1', '0', '1577729866', '1609446588');
INSERT INTO `mac_category` VALUES ('3', '腾讯视频专区', '3', '111899,111098,111069,112500,88719,111525,110278,110206,42837,6585,109770,218,35119,33345,15977,5508,49590,37561,10757,12798,11290,9707,103087,73918,10149,103391,108182,112936,11338,79936,109570,110837,111507,112760,111960,112953,47629,42594,37544,17729', '1', '0', '1577729909', '1609446527');
INSERT INTO `mac_category` VALUES ('4', '优酷视频专区', '2', '111098,88719,111525,110684,35478,11821,6585,218,35119,19036,15977,95459,49590,108312,103087,18238,13355,13178,12688,6842,67176,38043,113086,108182,113083,35657,11387,11338,110839,110761,109765,108443,79936,109868,111697,67413,111507,49310,6778,37544', '1', '0', '1577729960', '1609446452');
INSERT INTO `mac_category` VALUES ('5', '最热喜剧大片', '1', '113199,113198,113193,113192,113191,113190,113189,113188,113187,113186,113185,98785,98784,98783,89532,89514,88552,87972,86424,86058,85624,82470,81332,76797,76752,76736,76322,76169,76077,113201,113200,113197,113196,94548,92124,91673,91645,91432,91040,90544', '1', '0', '1577730105', '1609446363');
INSERT INTO `mac_category` VALUES ('6', '热门电视剧推荐', '6', '113184,113183,113182,113181,113180,113179,112935,112934,111074,88515,113208,113207,113206,113205,113204,113195,113203,113202,113160,113062', '1', '2', '1609447043', '1609447175');
INSERT INTO `mac_category` VALUES ('7', '热门综艺推荐', '0', '113178,113177,113176,111347,108138,106489,108105,104393,73148,56748,56607,47662,579,104034,56747,57181,57800,56700,56587,56612', '1', '1', '1609447393', '1609447472');
INSERT INTO `mac_category` VALUES ('8', '热门电视剧推荐', '8', '113184,113183,113182,113181,113180,113179,112935,112934,111074,88515,113208,113207,113206,113205,113204,113195,113203,113202,113160,113062', '1', '0', '1609447723', '1609447751');
INSERT INTO `mac_category` VALUES ('9', '热门动漫推荐', '9', '113194,107346,101921,58384,56738,52855,50778,100477,102911,103726,56860,56750,56333,43020,113088,112922,113087,4394,109780,101832', '1', '0', '1609447833', '1609447876');

-- -----------------------------
-- Table structure for `mac_cj_content`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cj_content`;
CREATE TABLE `mac_cj_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `url` char(255) NOT NULL,
  `title` char(100) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `nodeid` (`nodeid`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_cj_history`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cj_history`;
CREATE TABLE `mac_cj_history` (
  `md5` char(32) NOT NULL,
  PRIMARY KEY (`md5`) USING BTREE,
  KEY `md5` (`md5`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;


-- -----------------------------
-- Table structure for `mac_cj_node`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cj_node`;
CREATE TABLE `mac_cj_node` (
  `nodeid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sourcecharset` varchar(8) NOT NULL,
  `sourcetype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `urlpage` text NOT NULL,
  `pagesize_start` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pagesize_end` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `page_base` char(255) NOT NULL,
  `par_num` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `url_contain` char(100) NOT NULL,
  `url_except` char(100) NOT NULL,
  `url_start` char(100) NOT NULL DEFAULT '',
  `url_end` char(100) NOT NULL DEFAULT '',
  `title_rule` char(100) NOT NULL,
  `title_html_rule` text NOT NULL,
  `type_rule` char(100) NOT NULL,
  `type_html_rule` text NOT NULL,
  `content_rule` char(100) NOT NULL,
  `content_html_rule` text NOT NULL,
  `content_page_start` char(100) NOT NULL,
  `content_page_end` char(100) NOT NULL,
  `content_page_rule` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_nextpage` char(100) NOT NULL,
  `down_attachment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `watermark` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `coll_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `customize_config` text NOT NULL,
  `program_config` text NOT NULL,
  `mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`nodeid`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_collect`
-- -----------------------------
DROP TABLE IF EXISTS `mac_collect`;
CREATE TABLE `mac_collect` (
  `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `collect_name` varchar(30) NOT NULL DEFAULT '',
  `collect_url` varchar(255) NOT NULL DEFAULT '',
  `collect_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `collect_mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `collect_appid` varchar(30) NOT NULL DEFAULT '',
  `collect_appkey` varchar(30) NOT NULL DEFAULT '',
  `collect_param` varchar(100) NOT NULL DEFAULT '',
  `collect_opt` int(2) NOT NULL,
  `collect_filter` int(2) NOT NULL DEFAULT '0',
  `collect_filter_from` varchar(255) NOT NULL,
  PRIMARY KEY (`collect_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP数据采集';

-- -----------------------------
-- Records of `mac_collect`
-- -----------------------------
INSERT INTO `mac_collect` VALUES ('21', '百度', 'https://m3u8.dbyunzy.com/api.php/provide/vod/?ac=list', '2', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('33', 'V8', 'https://zy.sujx.top/api.php/provide/vod/at/xml/', '1', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('25', '天空资源站', 'https://m3u8.tiankongapi.com/api.php/provide/vod/?ac=list', '2', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('26', '天空1', 'https://api.tiankongapi.com/api.php/provide/vod/at/xml/', '1', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('28', '快播', 'http://www.kuaibozy.com/api.php/provide/vod/from/kbm3u8/at/xml/', '1', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('30', '八戒资源', 'http://cj.bajiecaiji.com/inc/api.php', '1', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('37', '官方', 'http://www.zycaiji.net:7788/api.php/provide/vod/?ac=list', '2', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('40', '神话1', 'http://shenhua.run/api.php/provide/vod/?ac=list', '2', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('41', 'zhibo', 'https://997.yuanmajs.cn/api.php/provide/vod/?ac=list', '2', '1', '', '', '', '0', '0', '');
INSERT INTO `mac_collect` VALUES ('42', 'zhibo', 'https://997.yuanmajs.cn/api.php/provide/vod/?ac=list', '2', '1', '', '', '', '0', '0', '');

-- -----------------------------
-- Table structure for `mac_comment`
-- -----------------------------
DROP TABLE IF EXISTS `mac_comment`;
CREATE TABLE `mac_comment` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment_mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `comment_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `comment_name` varchar(60) NOT NULL DEFAULT '',
  `comment_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_content` varchar(255) NOT NULL DEFAULT '',
  `comment_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_reply` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_report` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`) USING BTREE,
  KEY `comment_mid` (`comment_mid`) USING BTREE,
  KEY `comment_rid` (`comment_rid`) USING BTREE,
  KEY `comment_time` (`comment_time`) USING BTREE,
  KEY `comment_pid` (`comment_pid`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `comment_reply` (`comment_reply`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP评论数据';

-- -----------------------------
-- Records of `mac_comment`
-- -----------------------------
INSERT INTO `mac_comment` VALUES ('1', '1', '61243', '0', '61', '1', '天诚影视F2CJE', '1880584993', '1601916039', '不错', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('2', '1', '57847', '0', '46', '1', '天诚影视SV0LA', '0', '1601989001', '哇喔', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('3', '1', '74029', '0', '61', '1', '天诚影视F2CJE', '1880584993', '1602051835', '哈哈哈', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('4', '1', '57601', '0', '74', '1', '天诚影视LUBKX', '1033706355', '1603437553', '一直缓冲是怎么回事呢', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('5', '1', '115662', '0', '91', '1', '天诚影视H984C', '0', '1616811963', '测试', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('6', '1', '120017', '0', '96', '1', '天诚影视8MLIG', '0', '1617077574', '', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('7', '1', '120017', '0', '96', '1', '天诚影视8MLIG', '0', '1617077599', '真棒', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('8', '1', '141435', '0', '132', '1', '天诚影视GBMUU', '0', '1625373405', '不错', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('9', '1', '148257', '0', '184', '1', '天诚影视9NFPN', '1857704333', '1631515300', '哭了，', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('10', '1', '149884', '0', '184', '1', '天诚影视9NFPN', '1857704333', '1631716181', '', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('11', '1', '155257', '0', '193', '1', 'E8X5D', '453937890', '1643038872', '这广告', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('12', '1', '260217', '0', '194', '1', '大河原唯梨', '453937890', '1643450260', '这种战争片特别有意思', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('13', '1', '260297', '0', '202', '1', 'HPS6U', '453904877', '1643608976', '挺搞笑的', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('14', '1', '260257', '0', '202', '1', 'HPS6U', '453904877', '1643609006', '大片', '0', '0', '0', '0');
INSERT INTO `mac_comment` VALUES ('15', '1', '420093', '0', '223', '1', 'Z2T0A', '1728485328', '1644249093', '测试一下评论', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `mac_danmu`
-- -----------------------------
DROP TABLE IF EXISTS `mac_danmu`;
CREATE TABLE `mac_danmu` (
  `danmu_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `vod_id` int(11) NOT NULL,
  `at_time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `danmu_time` int(11) NOT NULL,
  `status` int(255) NOT NULL DEFAULT '1',
  `dianzan_num` int(11) NOT NULL DEFAULT '0',
  `danmu_ip` char(200) NOT NULL,
  `color` char(50) NOT NULL,
  PRIMARY KEY (`danmu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COMMENT='弹幕';

-- -----------------------------
-- Records of `mac_danmu`
-- -----------------------------
INSERT INTO `mac_danmu` VALUES ('1', '。。。。', '57271', '2147483647', '51', '1601731120', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('2', '吊', '57271', '2147483647', '51', '1601731134', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('3', '这个软件好用', '57271', '2147483647', '51', '1601731151', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('4', '有人吗', '56618', '2147483647', '46', '1601906953', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('5', '哈', '74030', '2147483647', '46', '1601950187', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('6', '哇喔', '56680', '2147483647', '46', '1602067522', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('7', '搞笑', '57051', '2147483647', '46', '1602240662', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('8', '鬼怎么会有影子？', '71347', '2147483647', '70', '1603626959', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('9', '好看', '119075', '2147483647', '91', '1616767535', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('10', '有人吗', '119075', '2147483647', '91', '1616767552', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('11', '好看', '117336', '2147483647', '96', '1616950335', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('12', '有人吗', '117336', '2147483647', '96', '1616950347', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('13', '看不到吗', '117336', '2147483647', '96', '1616950476', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('14', '哈哈', '117336', '2147483647', '97', '1616950528', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('15', '好看', '117336', '2147483647', '96', '1616950555', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('16', '欢欢加油', '122337', '2147483647', '74', '1619795271', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('17', '刻板，呆滞', '56864', '2147483647', '73', '1632069157', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('18', '金刚伞不是都掉了吗', '113084', '2147483647', '74', '1632262831', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('19', '吐了', '148796', '2147483647', '191', '1632464963', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('20', '弹幕测试', '2602360', '9324', '194', '1643361793', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('21', '弹幕测试', '2602360', '10801', '194', '1643362423', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('22', '可以可以', '2602360', '98312', '194', '1643362510', '1', '0', '', '');
INSERT INTO `mac_danmu` VALUES ('23', '刀模他儿', '2602360', '2806', '194', '1643363407', '1', '0', '2073294351', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('24', '人间值得', '2848180', '10553', '194', '1643367358', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('25', '洗冤录，逻辑推理大师', '2682880', '15071', '194', '1643367680', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('26', '毒贩可恶啊', '2677160', '68133', '194', '1643367941', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('27', '玲珑好漂亮', '2896470', '197890', '194', '1643374248', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('28', '哈哈，这爹好玩！', '2896470', '391831', '194', '1643374474', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('29', '完美伴侣，', '2650520', '9791', '194', '1643448838', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('30', '科幻，战争边缘', '2602170', '29329', '194', '1643448974', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('31', '绑这里三天！', '26031140', '212553', '194', '1643474540', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('32', '完美伴侣，挺好看的', '26505214', '138919', '194', '1643528133', '1', '0', '453937890', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('33', '片子不错！', '2602570', '27704', '202', '1643609026', '1', '0', '453904877', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('34', '这片子有点虐', '2650520', '22222', '194', '1643771959', '1', '0', '453904877', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('35', '港片确实不错！', '2821230', '245953', '194', '1643780793', '1', '0', '453904877', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('36', '好久没看香港剧了，这部片挺不错的！', '3489640', '33388', '194', '1643813268', '1', '0', '453904877', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('37', '不错的剧，追下去！', '3489640', '35545', '209', '1643813471', '1', '0', '453904877', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('38', '模块里', '2804620', '9771', '220', '1643858421', '1', '0', '2111008610', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('39', '测试一下', '4200930', '17498', '223', '1644249284', '1', '0', '1728485328', '#FFFFFF');
INSERT INTO `mac_danmu` VALUES ('40', '人', '4261591', '1597', '231', '1644256742', '1', '0', '1880222754', '#FFFFFF');

-- -----------------------------
-- Table structure for `mac_gbook`
-- -----------------------------
DROP TABLE IF EXISTS `mac_gbook`;
CREATE TABLE `mac_gbook` (
  `gbook_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbook_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `gbook_name` varchar(60) NOT NULL DEFAULT '',
  `gbook_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_reply_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_content` varchar(255) NOT NULL DEFAULT '',
  `gbook_reply` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`gbook_id`) USING BTREE,
  KEY `gbook_rid` (`gbook_rid`) USING BTREE,
  KEY `gbook_time` (`gbook_time`) USING BTREE,
  KEY `gbook_reply_time` (`gbook_reply_time`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `gbook_reply` (`gbook_reply`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP留言反馈';

-- -----------------------------
-- Records of `mac_gbook`
-- -----------------------------
INSERT INTO `mac_gbook` VALUES ('2', '0', '51', '1', '天诚影视ID2B8', '0', '1603462129', '0', '看不了没法看', '');
INSERT INTO `mac_gbook` VALUES ('3', '0', '51', '1', '天诚影视ID2B8', '0', '1603462131', '0', '看不了没法看', '');
INSERT INTO `mac_gbook` VALUES ('4', '0', '51', '1', '天诚影视ID2B8', '1996815408', '1604287502', '1608187476', '看不了啊', '已修复');
INSERT INTO `mac_gbook` VALUES ('5', '0', '51', '1', '天诚影视ID2B8', '1987167107', '1610368179', '0', '看不了', '');
INSERT INTO `mac_gbook` VALUES ('6', '0', '74', '1', '天诚影视LUBKX', '0', '1622251920', '0', '视频《星途叵测第二季普通话版》播放失败播放源：奇艺视频视频序列：第3集视频源地址：***://***.iqiyi.***/v_118vwu3hja0.html', '');
INSERT INTO `mac_gbook` VALUES ('7', '0', '74', '1', '天诚影视LUBKX', '0', '1622251929', '0', '视频《星途叵测第二季普通话版》播放失败播放源：奇艺视频视频序列：第3集视频源地址：***://***.iqiyi.***/v_118vwu3hja0.html', '');
INSERT INTO `mac_gbook` VALUES ('8', '0', '123', '1', '天诚影视OYHLQ', '1901604311', '1623481843', '0', '视频《狐狸的夏天第一季》播放失败播放源：腾讯视频视频序列：16视频源地址：***s://v.qq.***/x/cover/hz1jkqvpb4detvb/g00232ufpel.html', '');
INSERT INTO `mac_gbook` VALUES ('9', '0', '133', '1', '天诚影视D6DSM', '0', '1624547664', '0', '视频《长相守》播放失败播放源：百度云视频序列：第51集视频源地址：***s://video.buycar5.cn/20200918/NJcwAjm8/index.m3u8', '');
INSERT INTO `mac_gbook` VALUES ('10', '0', '133', '1', '天诚影视D6DSM', '0', '1624547705', '0', '看一会儿卡一会儿，是怎么回事啊', '');
INSERT INTO `mac_gbook` VALUES ('11', '0', '124', '1', '天诚影视2GMIV', '1974536529', '1625584082', '0', '视频《寻梦环游记（普通话）》播放失败播放源：奇艺视频视频序列：高清视频源地址：***://***.iqiyi.***/v_19rrfqa6n8.html', '');
INSERT INTO `mac_gbook` VALUES ('12', '0', '124', '1', '天诚影视2GMIV', '1974536529', '1625584085', '0', '视频《寻梦环游记（普通话）》播放失败播放源：奇艺视频视频序列：高清视频源地址：***://***.iqiyi.***/v_19rrfqa6n8.html', '');
INSERT INTO `mac_gbook` VALUES ('13', '0', '60', '1', '天诚影视SDBBO', '0', '1629993477', '1630203522', '视频《玉楼春》播放失败播放源：优酷视频视频序列：第35集视频源地址：***s://v.youku.***/v_show/id_XNTE4Nzg4ODc4OA==.html', '经测试可正常播放，如播放失败请更换播放来源或稍后尝试！');
INSERT INTO `mac_gbook` VALUES ('14', '0', '171', '1', '天诚影视QV7WP', '1880229688', '1631031968', '1631366702', '视频《中国医生战疫版》播放失败播放源：奇艺视频视频序列：2020-08-19期', '经测试可正常播放，如播放失败请更换播放来源或稍后尝试！');
INSERT INTO `mac_gbook` VALUES ('15', '0', '74', '1', '天诚影视LUBKX', '0', '1631380220', '0', '视频《最强铁血奶爸》播放失败播放源：极速播放视频序列：高清视频源地址：***s://video.dious.cc/20200707/031j5mdM/index.m3u8几秒钟停一下反复这样，几个都试了还是要卡', '');
INSERT INTO `mac_gbook` VALUES ('16', '0', '74', '1', '天诚影视LUBKX', '0', '1631380222', '0', '视频《最强铁血奶爸》播放失败播放源：极速播放视频序列：高清视频源地址：***s://video.dious.cc/20200707/031j5mdM/index.m3u8几秒钟停一下反复这样，几个都试了还是要卡', '');
INSERT INTO `mac_gbook` VALUES ('17', '0', '74', '1', '天诚影视LUBKX', '0', '1631380797', '0', '视频《狗狗间谍》播放失败播放源：百度云视频序列：HD视频源地址：***s://vod3.bdzybf3.***/20210214/3gMOaxU5/index.m3u8这个也看不起', '');
INSERT INTO `mac_gbook` VALUES ('18', '0', '96', '1', '15928032914', '0', '1631444126', '1632098742', 'ID:148466 -【名称：百灵潭 - 第19集】无法观看请检查修复', '经测试可正常播放');
INSERT INTO `mac_gbook` VALUES ('19', '0', '74', '1', '天诚影视LUBKX', '0', '1632266354', '0', '视频《昆仑神宫》播放失败播放源：腾讯视频视频序列：高清', '');
INSERT INTO `mac_gbook` VALUES ('20', '0', '74', '1', '天诚影视LUBKX', '0', '1632266417', '0', '返回又好了', '');
INSERT INTO `mac_gbook` VALUES ('21', '0', '181', '1', '天诚影视YION0', '1971855851', '1632389120', '0', '视频《巡回检察组 DVD版》播放失败播放源：优酷视频视频序列：33视频源地址：***://v.youku.***/v_show/id_XNTAwOTQ5OTA0OA==.html', '');
INSERT INTO `mac_gbook` VALUES ('22', '0', '181', '1', '天诚影视YION0', '1971855851', '1632389120', '0', '视频《巡回检察组 DVD版》播放失败播放源：优酷视频视频序列：33视频源地址：***://v.youku.***/v_show/id_XNTAwOTQ5OTA0OA==.html', '');
INSERT INTO `mac_gbook` VALUES ('23', '0', '192', '1', '天诚影视KOHNR', '454022852', '1640780229', '0', '留言测试', '');
INSERT INTO `mac_gbook` VALUES ('24', '0', '192', '1', '木华', '453937708', '1641229417', '0', '视频《抗日传奇：铁道游击队》播放失败播放源：优酷视频视频序列：HD视频源地址：***s://v.youku.***/v_nextstage/id_bcbe749de8f1447890fc.html', '');
INSERT INTO `mac_gbook` VALUES ('25', '0', '194', '1', '大河原唯梨', '453904877', '1643805650', '0', '视频数据：舌尖上的心跳 播放失败视频来源：腾讯视频视频序号：第5集视频地址：***s://v.***.***/x/cover/mzc00200htpzo0y/q0041lzvlq1.html', '');

-- -----------------------------
-- Table structure for `mac_glog`
-- -----------------------------
DROP TABLE IF EXISTS `mac_glog`;
CREATE TABLE `mac_glog` (
  `glog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_1` int(10) NOT NULL DEFAULT '0',
  `glog_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `glog_gold` smallint(6) unsigned NOT NULL DEFAULT '0',
  `glog_time` int(10) unsigned NOT NULL DEFAULT '0',
  `glog_remarks` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`glog_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `glog_type` (`glog_type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='发起提现';

-- -----------------------------
-- Records of `mac_glog`
-- -----------------------------
INSERT INTO `mac_glog` VALUES ('1', '46', '0', '4', '65535', '1601824931', '发起提现，');
INSERT INTO `mac_glog` VALUES ('2', '46', '0', '4', '65535', '1601826153', '发起提现，');
INSERT INTO `mac_glog` VALUES ('3', '46', '0', '4', '65535', '1601826201', '发起提现，');
INSERT INTO `mac_glog` VALUES ('4', '46', '0', '5', '65535', '1601826260', '提现失败，原路返回账户');
INSERT INTO `mac_glog` VALUES ('5', '46', '0', '5', '65535', '1601826274', '提现失败，原路返回账户');
INSERT INTO `mac_glog` VALUES ('6', '97', '0', '4', '65535', '1617855225', '发起提现，');
INSERT INTO `mac_glog` VALUES ('7', '97', '0', '5', '65535', '1617855295', '提现失败，原路返回账户');
INSERT INTO `mac_glog` VALUES ('8', '97', '0', '4', '100', '1617861167', '发起提现，');
INSERT INTO `mac_glog` VALUES ('9', '97', '0', '4', '456', '1618567058', '发起提现，');
INSERT INTO `mac_glog` VALUES ('10', '97', '0', '4', '100', '1618567335', '发起提现，');
INSERT INTO `mac_glog` VALUES ('11', '194', '0', '4', '45000', '1643513429', '发起提现，');
INSERT INTO `mac_glog` VALUES ('12', '194', '0', '5', '45000', '1643513592', '提现失败，原路返回账户');
INSERT INTO `mac_glog` VALUES ('13', '194', '0', '4', '45000', '1643513630', '发起提现，');

-- -----------------------------
-- Table structure for `mac_gold_withdraw_apply`
-- -----------------------------
DROP TABLE IF EXISTS `mac_gold_withdraw_apply`;
CREATE TABLE `mac_gold_withdraw_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `num` decimal(8,2) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 审批中 1 提现成功 2 提现失败',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `created_time` int(11) NOT NULL COMMENT '创建时间',
  `updated_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `success_time` int(11) NOT NULL DEFAULT '0' COMMENT '// 提现成功时间',
  `fail_time` int(11) NOT NULL DEFAULT '0' COMMENT '// 结束时间',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '提现方式',
  `account` varchar(255) NOT NULL DEFAULT '0' COMMENT '账户',
  `realname` varchar(255) NOT NULL DEFAULT '''''' COMMENT '真实姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='金币提现申请';


-- -----------------------------
-- Table structure for `mac_group`
-- -----------------------------
DROP TABLE IF EXISTS `mac_group`;
CREATE TABLE `mac_group` (
  `group_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) NOT NULL DEFAULT '',
  `group_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `group_type` varchar(255) NOT NULL DEFAULT '',
  `group_popedom` text NOT NULL,
  `group_points_day` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_week` smallint(6) NOT NULL DEFAULT '0',
  `group_points_month` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_year` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_free` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`) USING BTREE,
  KEY `group_status` (`group_status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员组管理';

-- -----------------------------
-- Records of `mac_group`
-- -----------------------------
INSERT INTO `mac_group` VALUES ('1', '游客', '1', ',1,2,3,4,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"4\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"}}', '0', '0', '0', '0', '0');
INSERT INTO `mac_group` VALUES ('2', '默认会员', '1', ',1,2,3,4,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"4\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"}}', '0', '0', '0', '0', '0');
INSERT INTO `mac_group` VALUES ('3', '尊贵VIP会员', '1', ',1,2,3,4,33,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"4\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"33\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"}}', '100', '20', '300', '1200', '0');

-- -----------------------------
-- Table structure for `mac_groupchat`
-- -----------------------------
DROP TABLE IF EXISTS `mac_groupchat`;
CREATE TABLE `mac_groupchat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='群聊';


-- -----------------------------
-- Table structure for `mac_link`
-- -----------------------------
DROP TABLE IF EXISTS `mac_link`;
CREATE TABLE `mac_link` (
  `link_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `link_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `link_name` varchar(60) NOT NULL DEFAULT '',
  `link_sort` smallint(6) NOT NULL DEFAULT '0',
  `link_add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `link_time` int(10) unsigned NOT NULL DEFAULT '0',
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_logo` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`) USING BTREE,
  KEY `link_sort` (`link_sort`) USING BTREE,
  KEY `link_type` (`link_type`) USING BTREE,
  KEY `link_add_time` (`link_add_time`) USING BTREE,
  KEY `link_time` (`link_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_message`
-- -----------------------------
DROP TABLE IF EXISTS `mac_message`;
CREATE TABLE `mac_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `create_date` datetime NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='APP公告通知';

-- -----------------------------
-- Records of `mac_message`
-- -----------------------------
INSERT INTO `mac_message` VALUES ('1', '您好，感谢注册多咪视频', '2022-02-07 23:07:56', '即日起，庆祝多咪视频上线，全面开启邀请好友看片赚钱活动了！推广好友来看片，不仅可以升级兑换会员，还可以赚钱啦~');
INSERT INTO `mac_message` VALUES ('3', '更新通知', '2022-02-07 23:08:13', '1、全新UI界面更新2、修复官方播放器，重写全局播放，更流畅3、增加播放记录删除功能4、增加用户手动设置跳过片头、片尾5、新增退出后打开提示上次观看记录6、修复播放时提示网络连接失败7、修复部分手机闪退8、更多精彩等您发现');

-- -----------------------------
-- Table structure for `mac_msg`
-- -----------------------------
DROP TABLE IF EXISTS `mac_msg`;
CREATE TABLE `mac_msg` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `msg_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `msg_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `msg_to` varchar(30) NOT NULL DEFAULT '',
  `msg_code` varchar(10) NOT NULL DEFAULT '',
  `msg_content` varchar(255) NOT NULL DEFAULT '',
  `msg_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`) USING BTREE,
  KEY `msg_code` (`msg_code`) USING BTREE,
  KEY `msg_time` (`msg_time`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `mac_msg`
-- -----------------------------
INSERT INTO `mac_msg` VALUES ('1', '0', '3', '0', '13398357242', '820320', '', '1607752033');
INSERT INTO `mac_msg` VALUES ('2', '0', '3', '0', '13398357242', '085401', '', '1607752107');
INSERT INTO `mac_msg` VALUES ('3', '0', '3', '0', '19108163037', '010514', '', '1608038432');
INSERT INTO `mac_msg` VALUES ('4', '0', '3', '0', '18913058713', '464561', '', '1611112649');
INSERT INTO `mac_msg` VALUES ('5', '0', '3', '0', '18328025828', '412676', '', '1611147116');
INSERT INTO `mac_msg` VALUES ('6', '0', '3', '0', '18121895865', '055657', '', '1611744843');
INSERT INTO `mac_msg` VALUES ('7', '0', '3', '0', '18380329771', '905398', '', '1611900505');
INSERT INTO `mac_msg` VALUES ('8', '0', '3', '0', '19108163037', '959233', '', '1612969215');
INSERT INTO `mac_msg` VALUES ('9', '0', '3', '0', '13541729049', '844029', '', '1612999105');
INSERT INTO `mac_msg` VALUES ('10', '0', '3', '0', '18181387686', '228582', '', '1616746111');
INSERT INTO `mac_msg` VALUES ('11', '0', '3', '0', '15928032914', '398581', '', '1616756657');
INSERT INTO `mac_msg` VALUES ('12', '0', '3', '0', '15928032914', '788443', '', '1616756816');
INSERT INTO `mac_msg` VALUES ('13', '0', '3', '0', '13512345678', '957692', '', '1616759616');
INSERT INTO `mac_msg` VALUES ('14', '0', '3', '0', '18888888888', '642162', '', '1616821511');
INSERT INTO `mac_msg` VALUES ('15', '0', '2', '0', '18913058173', '124014', '', '1616826035');
INSERT INTO `mac_msg` VALUES ('16', '0', '2', '0', '18382184020', '453382', '', '1616835157');
INSERT INTO `mac_msg` VALUES ('17', '0', '3', '0', '18382184020', '611069', '', '1616844090');
INSERT INTO `mac_msg` VALUES ('18', '0', '3', '0', '13398357242', '331590', '', '1616853413');
INSERT INTO `mac_msg` VALUES ('19', '0', '3', '0', '13398357242', '431365', '', '1616853480');
INSERT INTO `mac_msg` VALUES ('20', '0', '3', '0', '18048604313', '697354', '', '1616853497');
INSERT INTO `mac_msg` VALUES ('21', '0', '3', '0', '15928032914', '046328', '', '1616853565');
INSERT INTO `mac_msg` VALUES ('22', '0', '3', '0', '18048604313', '169706', '', '1616853675');
INSERT INTO `mac_msg` VALUES ('23', '0', '3', '0', '18048604313', '078167', '', '1616853844');
INSERT INTO `mac_msg` VALUES ('24', '0', '3', '0', '13388112086', '185513', '', '1617024723');
INSERT INTO `mac_msg` VALUES ('25', '0', '3', '0', '18188642557', '834462', '', '1617076251');
INSERT INTO `mac_msg` VALUES ('26', '0', '2', '0', '15928032914', '375417', '', '1617164037');
INSERT INTO `mac_msg` VALUES ('27', '0', '3', '0', '15719326616', '436541', '', '1617197503');
INSERT INTO `mac_msg` VALUES ('28', '0', '3', '0', '18116520174', '611040', '', '1618501667');
INSERT INTO `mac_msg` VALUES ('29', '0', '3', '0', '18781611116', '726344', '', '1618648388');
INSERT INTO `mac_msg` VALUES ('30', '0', '3', '0', '18012762873', '874571', '', '1618915206');
INSERT INTO `mac_msg` VALUES ('31', '0', '3', '0', '13281755113', '934766', '', '1619347308');
INSERT INTO `mac_msg` VALUES ('32', '0', '2', '0', '13662722709', '214394', '', '1619761811');
INSERT INTO `mac_msg` VALUES ('33', '0', '3', '0', '13398357242', '797243', '', '1619796595');
INSERT INTO `mac_msg` VALUES ('34', '0', '3', '0', '13411648496', '169001', '', '1619940434');
INSERT INTO `mac_msg` VALUES ('35', '0', '3', '0', '13411648496', '337176', '', '1619940534');
INSERT INTO `mac_msg` VALUES ('36', '0', '3', '0', '13438006822', '659544', '', '1620091236');
INSERT INTO `mac_msg` VALUES ('37', '0', '3', '0', '18507600831', '115066', '', '1620714054');
INSERT INTO `mac_msg` VALUES ('38', '0', '3', '0', '18981133895', '554671', '', '1620714968');
INSERT INTO `mac_msg` VALUES ('39', '0', '3', '0', '17327666658', '816345', '', '1621319238');
INSERT INTO `mac_msg` VALUES ('40', '0', '3', '0', '18583171316', '616262', '', '1621591168');
INSERT INTO `mac_msg` VALUES ('41', '0', '3', '0', '17628010149', '552574', '', '1621757630');
INSERT INTO `mac_msg` VALUES ('42', '0', '3', '0', '13728993493', '064448', '', '1621832689');
INSERT INTO `mac_msg` VALUES ('43', '0', '3', '0', '18784061661', '223836', '', '1622204995');
INSERT INTO `mac_msg` VALUES ('44', '0', '3', '0', '18208181694', '250687', '', '1622247537');
INSERT INTO `mac_msg` VALUES ('45', '0', '2', '0', '15008165740', '568623', '', '1622264405');
INSERT INTO `mac_msg` VALUES ('46', '0', '2', '0', '15008165740', '471219', '', '1622264928');
INSERT INTO `mac_msg` VALUES ('47', '0', '3', '0', '18781611116', '697681', '', '1622274193');
INSERT INTO `mac_msg` VALUES ('48', '0', '3', '0', '18349399430', '254182', '', '1622278575');
INSERT INTO `mac_msg` VALUES ('49', '0', '3', '0', '18349399430', '098528', '', '1622278729');
INSERT INTO `mac_msg` VALUES ('50', '0', '2', '0', '18349399430', '999957', '', '1622278977');
INSERT INTO `mac_msg` VALUES ('51', '0', '3', '0', '18300666252', '887719', '', '1622361783');
INSERT INTO `mac_msg` VALUES ('52', '0', '3', '0', '19808110717', '576005', '', '1622887757');
INSERT INTO `mac_msg` VALUES ('53', '0', '3', '0', '17748159171', '749920', '', '1622994822');
INSERT INTO `mac_msg` VALUES ('54', '0', '3', '0', '17748159171', '328866', '', '1622994891');
INSERT INTO `mac_msg` VALUES ('55', '0', '2', '0', '19938765424', '791417', '', '1623074147');
INSERT INTO `mac_msg` VALUES ('56', '0', '3', '0', '19938765424', '955799', '', '1623074327');
INSERT INTO `mac_msg` VALUES ('57', '0', '3', '0', '19938765424', '348158', '', '1623074397');
INSERT INTO `mac_msg` VALUES ('58', '0', '3', '0', '19938765424', '174864', '', '1623074543');
INSERT INTO `mac_msg` VALUES ('59', '0', '3', '0', '19938765424', '870944', '', '1623074718');
INSERT INTO `mac_msg` VALUES ('60', '0', '3', '0', '13398357242', '005068', '', '1623074800');
INSERT INTO `mac_msg` VALUES ('61', '0', '3', '0', '13398357242', '855898', '', '1623075319');
INSERT INTO `mac_msg` VALUES ('62', '0', '3', '0', '13398357242', '618167', '', '1623075749');
INSERT INTO `mac_msg` VALUES ('63', '0', '3', '0', '19180135096', '031441', '', '1623136981');
INSERT INTO `mac_msg` VALUES ('64', '0', '3', '0', '19180135096', '122942', '', '1623137096');
INSERT INTO `mac_msg` VALUES ('65', '0', '2', '0', '18080254159', '314389', '', '1623675615');
INSERT INTO `mac_msg` VALUES ('66', '0', '2', '0', '18781163278', '269634', '', '1623927308');
INSERT INTO `mac_msg` VALUES ('67', '0', '2', '0', '18349399430', '250120', '', '1624421539');
INSERT INTO `mac_msg` VALUES ('68', '0', '3', '0', '13696269640', '234577', '', '1624540695');
INSERT INTO `mac_msg` VALUES ('69', '0', '2', '0', '13662722709', '489805', '', '1624681195');
INSERT INTO `mac_msg` VALUES ('70', '0', '2', '0', '13411648496', '077679', '', '1624773117');
INSERT INTO `mac_msg` VALUES ('71', '0', '2', '0', '13411648496', '616473', '', '1624773509');
INSERT INTO `mac_msg` VALUES ('72', '0', '3', '0', '13268355404', '366308', '', '1624883485');
INSERT INTO `mac_msg` VALUES ('73', '0', '2', '0', '13398357242', '093471', '', '1625137528');
INSERT INTO `mac_msg` VALUES ('74', '0', '3', '0', '19173600466', '863574', '', '1625303204');
INSERT INTO `mac_msg` VALUES ('75', '0', '2', '0', '19173600466', '402719', '', '1625303274');
INSERT INTO `mac_msg` VALUES ('76', '0', '3', '0', '18080243033', '728081', '', '1625403885');
INSERT INTO `mac_msg` VALUES ('77', '0', '3', '0', '15882883559', '001949', '', '1626087096');
INSERT INTO `mac_msg` VALUES ('78', '0', '3', '0', '18781163278', '260149', '', '1626161208');
INSERT INTO `mac_msg` VALUES ('79', '0', '3', '0', '18206000173', '088596', '', '1626341414');
INSERT INTO `mac_msg` VALUES ('80', '0', '2', '0', '13662722709', '709024', '', '1626531672');
INSERT INTO `mac_msg` VALUES ('81', '0', '3', '0', '18317602297', '925454', '', '1626977077');
INSERT INTO `mac_msg` VALUES ('82', '0', '3', '0', '15223966826', '824481', '', '1627209541');
INSERT INTO `mac_msg` VALUES ('83', '0', '2', '0', '18080254159', '515525', '', '1627349343');
INSERT INTO `mac_msg` VALUES ('84', '0', '3', '0', '18483685816', '568112', '', '1627698192');
INSERT INTO `mac_msg` VALUES ('85', '0', '2', '0', '13411648496', '624006', '', '1627700121');
INSERT INTO `mac_msg` VALUES ('86', '0', '3', '0', '17748159171', '860910', '', '1628152109');
INSERT INTO `mac_msg` VALUES ('87', '0', '3', '0', '18583938239', '178620', '', '1628308576');
INSERT INTO `mac_msg` VALUES ('88', '0', '3', '0', '17765365620', '997067', '', '1628371493');
INSERT INTO `mac_msg` VALUES ('89', '0', '3', '0', '19950851207', '324927', '', '1628518246');
INSERT INTO `mac_msg` VALUES ('90', '0', '2', '0', '18382537594', '359797', '', '1628606383');
INSERT INTO `mac_msg` VALUES ('91', '0', '3', '0', '13315654712', '024918', '', '1628771152');
INSERT INTO `mac_msg` VALUES ('92', '0', '2', '0', '13398357242', '219334', '', '1628908511');
INSERT INTO `mac_msg` VALUES ('93', '0', '3', '0', '13398357242', '578442', '', '1628908564');
INSERT INTO `mac_msg` VALUES ('94', '0', '3', '0', '17765365620', '096850', '', '1628908585');
INSERT INTO `mac_msg` VALUES ('95', '0', '2', '0', '13398357242', '603024', '', '1628908717');
INSERT INTO `mac_msg` VALUES ('96', '0', '3', '0', '17765365620', '958761', '', '1628910723');
INSERT INTO `mac_msg` VALUES ('97', '0', '2', '0', '13398357242', '268999', '', '1628913480');
INSERT INTO `mac_msg` VALUES ('98', '0', '3', '0', '18639358311', '612478', '', '1628914298');
INSERT INTO `mac_msg` VALUES ('99', '0', '3', '0', '17765365620', '515608', '', '1628914717');
INSERT INTO `mac_msg` VALUES ('100', '0', '3', '0', '15204004228', '525194', '', '1628919118');
INSERT INTO `mac_msg` VALUES ('101', '0', '3', '0', '19872159153', '982275', '', '1628928686');
INSERT INTO `mac_msg` VALUES ('102', '0', '3', '0', '16602151032', '570887', '', '1628942979');
INSERT INTO `mac_msg` VALUES ('103', '0', '3', '0', '13568825870', '556840', '', '1629627719');
INSERT INTO `mac_msg` VALUES ('104', '0', '3', '0', '13398357242', '095811', '', '1629629598');
INSERT INTO `mac_msg` VALUES ('105', '0', '3', '0', '13530416330', '051208', '', '1629862770');
INSERT INTO `mac_msg` VALUES ('106', '0', '3', '0', '15281632223', '819595', '', '1629962226');
INSERT INTO `mac_msg` VALUES ('107', '0', '3', '0', '19950802005', '102428', '', '1629974749');
INSERT INTO `mac_msg` VALUES ('108', '0', '3', '0', '18589330253', '586649', '', '1630213609');
INSERT INTO `mac_msg` VALUES ('109', '0', '3', '0', '13038760521', '521100', '', '1630305094');
INSERT INTO `mac_msg` VALUES ('110', '0', '3', '0', '19525116017', '699291', '', '1630329063');
INSERT INTO `mac_msg` VALUES ('111', '0', '3', '0', '18780323810', '234063', '', '1630403986');
INSERT INTO `mac_msg` VALUES ('112', '0', '2', '0', '13398357242', '415607', '', '1630505514');
INSERT INTO `mac_msg` VALUES ('113', '0', '2', '0', '13411648496', '054372', '', '1630589570');
INSERT INTO `mac_msg` VALUES ('114', '0', '3', '0', '18030931166', '366402', '', '1630633067');
INSERT INTO `mac_msg` VALUES ('115', '0', '3', '0', '18608099799', '331131', '', '1630633235');
INSERT INTO `mac_msg` VALUES ('116', '0', '3', '0', '13981162643', '911405', '', '1630633613');
INSERT INTO `mac_msg` VALUES ('117', '0', '3', '0', '13881125827', '080750', '', '1630636754');
INSERT INTO `mac_msg` VALUES ('118', '0', '3', '0', '18380567255', '490524', '', '1630638682');
INSERT INTO `mac_msg` VALUES ('119', '0', '3', '0', '18144250255', '215764', '', '1630643744');
INSERT INTO `mac_msg` VALUES ('120', '0', '3', '0', '18048608923', '607678', '', '1630644292');
INSERT INTO `mac_msg` VALUES ('121', '0', '3', '0', '13388116294', '510551', '', '1630646988');
INSERT INTO `mac_msg` VALUES ('122', '0', '3', '0', '13281582760', '564474', '', '1630650462');
INSERT INTO `mac_msg` VALUES ('123', '0', '3', '0', '15378227788', '339777', '', '1630736122');
INSERT INTO `mac_msg` VALUES ('124', '0', '3', '0', '13698197732', '172734', '', '1630749400');
INSERT INTO `mac_msg` VALUES ('125', '0', '3', '0', '13698197732', '194421', '', '1630749470');
INSERT INTO `mac_msg` VALUES ('126', '0', '3', '0', '15281131931', '066327', '', '1630887188');
INSERT INTO `mac_msg` VALUES ('127', '0', '3', '0', '15281131931', '300381', '', '1630887288');
INSERT INTO `mac_msg` VALUES ('128', '0', '3', '0', '13990110098', '267734', '', '1630887427');
INSERT INTO `mac_msg` VALUES ('129', '0', '3', '0', '17313652668', '699395', '', '1630908719');
INSERT INTO `mac_msg` VALUES ('130', '0', '3', '0', '13778105698', '798029', '', '1630933407');
INSERT INTO `mac_msg` VALUES ('131', '0', '3', '0', '13154441730', '498914', '', '1630966979');
INSERT INTO `mac_msg` VALUES ('132', '0', '2', '0', '13154441730', '546271', '', '1630967089');
INSERT INTO `mac_msg` VALUES ('133', '0', '3', '0', '13398357242', '295369', '', '1631004667');
INSERT INTO `mac_msg` VALUES ('134', '0', '3', '0', '15707481247', '414380', '', '1631022256');
INSERT INTO `mac_msg` VALUES ('135', '0', '2', '0', '13038760521', '984447', '', '1631022269');
INSERT INTO `mac_msg` VALUES ('136', '0', '3', '0', '14780240531', '144289', '', '1631024671');
INSERT INTO `mac_msg` VALUES ('137', '0', '3', '0', '17722801391', '051389', '', '1631031599');
INSERT INTO `mac_msg` VALUES ('138', '0', '3', '0', '17788783134', '266057', '', '1631031646');
INSERT INTO `mac_msg` VALUES ('139', '0', '3', '0', '15804098810', '619541', '', '1631101420');
INSERT INTO `mac_msg` VALUES ('140', '0', '3', '0', '15712006030', '743606', '', '1631103452');
INSERT INTO `mac_msg` VALUES ('141', '0', '3', '0', '15883798828', '610451', '', '1631239891');
INSERT INTO `mac_msg` VALUES ('142', '0', '3', '0', '13350991926', '503815', '', '1631239996');
INSERT INTO `mac_msg` VALUES ('143', '0', '3', '0', '13980123222', '099822', '', '1631433442');
INSERT INTO `mac_msg` VALUES ('144', '0', '3', '0', '15228727036', '319649', '', '1631511975');
INSERT INTO `mac_msg` VALUES ('145', '0', '3', '0', '17313652668', '770903', '', '1631630308');
INSERT INTO `mac_msg` VALUES ('146', '0', '2', '0', '17313652668', '872479', '', '1631630397');
INSERT INTO `mac_msg` VALUES ('147', '0', '3', '0', '18005327189', '940321', '', '1631715705');
INSERT INTO `mac_msg` VALUES ('148', '0', '3', '0', '18005327189', '095108', '', '1631715857');
INSERT INTO `mac_msg` VALUES ('149', '0', '3', '0', '18981833596', '476474', '', '1631869988');
INSERT INTO `mac_msg` VALUES ('150', '0', '3', '0', '13160300170', '228050', '', '1631884887');
INSERT INTO `mac_msg` VALUES ('151', '0', '3', '0', '13398357242', '823752', '', '1631952447');
INSERT INTO `mac_msg` VALUES ('152', '0', '3', '0', '13398357243', '763032', '', '1631952604');
INSERT INTO `mac_msg` VALUES ('153', '0', '3', '0', '17765365620', '121833', '', '1631952750');
INSERT INTO `mac_msg` VALUES ('154', '0', '3', '0', '18133537657', '759697', '', '1632017139');
INSERT INTO `mac_msg` VALUES ('155', '0', '3', '0', '13345732511', '023878', '', '1632400034');
INSERT INTO `mac_msg` VALUES ('156', '0', '3', '0', '13144513678', '488544', '', '1632464844');
INSERT INTO `mac_msg` VALUES ('157', '0', '2', '0', '13144513678', '937644', '', '1632466917');
INSERT INTO `mac_msg` VALUES ('158', '0', '3', '0', '15320401453', '256582', '', '1640780179');
INSERT INTO `mac_msg` VALUES ('159', '0', '3', '0', '15320401453', '759464', '', '1641229284');
INSERT INTO `mac_msg` VALUES ('160', '0', '2', '0', '15320401453', '920876', '', '1641229325');

-- -----------------------------
-- Table structure for `mac_order`
-- -----------------------------
DROP TABLE IF EXISTS `mac_order`;
CREATE TABLE `mac_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `order_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `order_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_points` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_pay_type` varchar(10) NOT NULL DEFAULT '',
  `order_pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_remarks` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`order_id`) USING BTREE,
  KEY `order_code` (`order_code`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `order_time` (`order_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=267 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `mac_order`
-- -----------------------------
INSERT INTO `mac_order` VALUES ('232', '220', '0', 'PAY20220203115104181482', '30.00', '1643860264', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('231', '194', '0', 'PAY20220202101446503199', '15.00', '1643768086', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('230', '194', '0', 'PAY20220201204519999058', '15.00', '1643719519', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('229', '194', '0', 'PAY20220131090642358205', '15.00', '1643591202', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('228', '194', '0', 'PAY20220131075718818176', '120.00', '1643587038', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('227', '194', '0', 'PAY20220131075649608170', '30.00', '1643587009', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('226', '194', '0', 'PAY20220130194330591542', '15.00', '1643543010', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('225', '194', '0', 'PAY20220130193840650340', '120.00', '1643542720', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('224', '194', '0', 'PAY20220130192758800760', '120.00', '1643542078', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('223', '194', '1', 'PAY20220130191523968958', '1.00', '1643541323', '10', 'qqepay', '1643541441', '');
INSERT INTO `mac_order` VALUES ('233', '222', '0', 'PAY20220207202702120031', '15.00', '1644236822', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('234', '222', '0', 'PAY20220207202714787523', '30.00', '1644236834', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('235', '222', '0', 'PAY20220207203128982898', '120.00', '1644237088', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('236', '221', '0', 'PAY20220207203427610500', '15.00', '1644237267', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('237', '221', '0', 'PAY20220207221921489973', '15.00', '1644243561', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('238', '222', '0', 'PAY20220207224915782498', '15.00', '1644245355', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('239', '222', '0', 'PAY20220207224922596217', '30.00', '1644245362', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('240', '222', '0', 'PAY20220207224928228365', '15.00', '1644245368', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('241', '222', '0', 'PAY20220207224930403021', '120.00', '1644245370', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('242', '222', '0', 'PAY20220207224945172771', '30.00', '1644245385', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('243', '222', '0', 'PAY20220207225105410867', '120.00', '1644245465', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('244', '222', '0', 'PAY20220207225110802407', '30.00', '1644245470', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('245', '222', '0', 'PAY20220207225211234077', '120.00', '1644245531', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('246', '222', '0', 'PAY20220207225215654579', '30.00', '1644245535', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('247', '222', '0', 'PAY20220207225234718390', '120.00', '1644245554', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('248', '229', '0', 'PAY20220208011919439320', '30.00', '1644254359', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('249', '233', '0', 'PAY20220208060644506676', '30.00', '1644271604', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('250', '238', '0', 'PAY20220210141934107967', '15.00', '1644473974', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('251', '238', '0', 'PAY20220210143327660979', '15.00', '1644474807', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('252', '238', '0', 'PAY20220210143353982413', '15.00', '1644474833', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('253', '238', '0', 'PAY20220210143416732545', '30.00', '1644474856', '300', '', '0', '');
INSERT INTO `mac_order` VALUES ('254', '238', '0', 'PAY20220210143443592657', '15.00', '1644474883', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('255', '238', '0', 'PAY20220210143505414588', '15.00', '1644474905', '150', '', '0', '');
INSERT INTO `mac_order` VALUES ('256', '238', '0', 'PAY20220210144010447239', '2.00', '1644475210', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('257', '238', '0', 'PAY20220210144123707774', '2.00', '1644475283', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('258', '238', '0', 'PAY20220210144219819034', '2.00', '1644475339', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('259', '238', '0', 'PAY20220210144236275138', '2.00', '1644475356', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('260', '238', '0', 'PAY20220210210941295913', '2.00', '1644498581', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('261', '243', '0', 'PAY20220211023650997127', '2.00', '1644518210', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('262', '243', '0', 'PAY20220211023653306800', '2.00', '1644518213', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('263', '243', '0', 'PAY20220211023703764543', '2.00', '1644518223', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('264', '229', '0', 'PAY20220211105117192200', '2.00', '1644547877', '20', '', '0', '');
INSERT INTO `mac_order` VALUES ('265', '229', '0', 'PAY20220211105143355707', '120.00', '1644547903', '1200', '', '0', '');
INSERT INTO `mac_order` VALUES ('266', '229', '0', 'PAY20220211105201787872', '120.00', '1644547921', '1200', '', '0', '');

-- -----------------------------
-- Table structure for `mac_plog`
-- -----------------------------
DROP TABLE IF EXISTS `mac_plog`;
CREATE TABLE `mac_plog` (
  `plog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_1` int(10) NOT NULL DEFAULT '0',
  `plog_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `plog_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `plog_time` int(10) unsigned NOT NULL DEFAULT '0',
  `plog_remarks` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`plog_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `plog_type` (`plog_type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `mac_plog`
-- -----------------------------
INSERT INTO `mac_plog` VALUES ('1', '224', '0', '10', '1', '1644248839', '');
INSERT INTO `mac_plog` VALUES ('2', '223', '0', '11', '1', '1644249093', '');
INSERT INTO `mac_plog` VALUES ('3', '223', '0', '13', '1', '1644249284', '用户234a6c5f0fe弹幕奖励1分');
INSERT INTO `mac_plog` VALUES ('4', '226', '0', '10', '1', '1644249454', '');
INSERT INTO `mac_plog` VALUES ('5', '223', '0', '10', '1', '1644249890', '');
INSERT INTO `mac_plog` VALUES ('6', '229', '0', '10', '1', '1644254352', '');
INSERT INTO `mac_plog` VALUES ('7', '231', '0', '13', '1', '1644256742', '用户afd57a5d077弹幕奖励1分');
INSERT INTO `mac_plog` VALUES ('8', '233', '0', '10', '1', '1644271630', '');
INSERT INTO `mac_plog` VALUES ('9', '227', '0', '10', '1', '1644300244', '');
INSERT INTO `mac_plog` VALUES ('10', '238', '0', '10', '5', '1644474788', '');
INSERT INTO `mac_plog` VALUES ('11', '238', '0', '7', '100', '1644475388', '');
INSERT INTO `mac_plog` VALUES ('12', '241', '0', '7', '20', '1644488937', '');
INSERT INTO `mac_plog` VALUES ('13', '241', '0', '10', '5', '1644488942', '');
INSERT INTO `mac_plog` VALUES ('14', '238', '0', '15', '3', '1644499033', '用户f0b9bedefc4分享奖励3分');
INSERT INTO `mac_plog` VALUES ('15', '243', '0', '10', '5', '1644500633', '');

-- -----------------------------
-- Table structure for `mac_role`
-- -----------------------------
DROP TABLE IF EXISTS `mac_role`;
CREATE TABLE `mac_role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `role_name` varchar(255) NOT NULL DEFAULT '',
  `role_en` varchar(255) NOT NULL DEFAULT '',
  `role_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_letter` char(1) NOT NULL DEFAULT '',
  `role_color` varchar(6) NOT NULL DEFAULT '',
  `role_actor` varchar(255) NOT NULL DEFAULT '',
  `role_remarks` varchar(100) NOT NULL DEFAULT '',
  `role_pic` varchar(255) NOT NULL DEFAULT '',
  `role_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `role_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_time` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `role_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `role_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `role_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_tpl` varchar(30) NOT NULL DEFAULT '',
  `role_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `role_content` text NOT NULL,
  PRIMARY KEY (`role_id`) USING BTREE,
  KEY `role_rid` (`role_rid`) USING BTREE,
  KEY `role_name` (`role_name`) USING BTREE,
  KEY `role_en` (`role_en`) USING BTREE,
  KEY `role_letter` (`role_letter`) USING BTREE,
  KEY `role_actor` (`role_actor`) USING BTREE,
  KEY `role_level` (`role_level`) USING BTREE,
  KEY `role_time` (`role_time`) USING BTREE,
  KEY `role_time_add` (`role_time_add`) USING BTREE,
  KEY `role_score` (`role_score`) USING BTREE,
  KEY `role_score_all` (`role_score_all`) USING BTREE,
  KEY `role_score_num` (`role_score_num`) USING BTREE,
  KEY `role_up` (`role_up`) USING BTREE,
  KEY `role_down` (`role_down`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_sign`
-- -----------------------------
DROP TABLE IF EXISTS `mac_sign`;
CREATE TABLE `mac_sign` (
  `sign_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `date` varchar(20) NOT NULL,
  `reward` varchar(500) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`sign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_sign`
-- -----------------------------
INSERT INTO `mac_sign` VALUES ('1', '38', '2020-08-24', '{\"points\":\"10\"}', '1598276493', '1598276493');
INSERT INTO `mac_sign` VALUES ('2', '40', '2020-08-28', '{\"points\":\"10\"}', '1598577212', '1598577212');
INSERT INTO `mac_sign` VALUES ('3', '41', '2020-08-29', '{\"points\":\"10\"}', '1598632028', '1598632028');
INSERT INTO `mac_sign` VALUES ('4', '43', '2020-08-29', '{\"points\":\"10\"}', '1598670526', '1598670526');
INSERT INTO `mac_sign` VALUES ('5', '40', '2020-08-30', '{\"points\":\"10\"}', '1598774312', '1598774312');
INSERT INTO `mac_sign` VALUES ('6', '49', '2020-10-03', '{\"points\":\"1\"}', '1601725198', '1601725198');
INSERT INTO `mac_sign` VALUES ('7', '48', '2020-10-03', '{\"points\":\"1\"}', '1601729706', '1601729706');
INSERT INTO `mac_sign` VALUES ('8', '51', '2020-10-03', '{\"points\":\"1\"}', '1601731021', '1601731021');
INSERT INTO `mac_sign` VALUES ('9', '53', '2020-10-03', '{\"points\":\"1\"}', '1601734760', '1601734760');
INSERT INTO `mac_sign` VALUES ('10', '60', '2020-10-04', '{\"points\":\"1\"}', '1601771802', '1601771802');
INSERT INTO `mac_sign` VALUES ('11', '49', '2020-10-04', '{\"points\":\"1\"}', '1601788411', '1601788411');
INSERT INTO `mac_sign` VALUES ('12', '61', '2020-10-04', '{\"points\":\"1\"}', '1601793887', '1601793887');
INSERT INTO `mac_sign` VALUES ('13', '66', '2020-10-04', '{\"points\":\"1\"}', '1601824038', '1601824038');
INSERT INTO `mac_sign` VALUES ('14', '68', '2020-10-05', '{\"points\":\"1\"}', '1601829354', '1601829354');
INSERT INTO `mac_sign` VALUES ('15', '69', '2020-10-05', '{\"points\":\"1\"}', '1601868004', '1601868004');
INSERT INTO `mac_sign` VALUES ('16', '65', '2020-10-05', '{\"points\":\"1\"}', '1601874224', '1601874224');
INSERT INTO `mac_sign` VALUES ('17', '71', '2020-10-05', '{\"points\":\"1\"}', '1601874996', '1601874996');
INSERT INTO `mac_sign` VALUES ('18', '61', '2020-10-06', '{\"points\":\"1\"}', '1601916007', '1601916007');
INSERT INTO `mac_sign` VALUES ('19', '91', '2021-03-27', '{\"points\":\"1\"}', '1616851886', '1616851886');
INSERT INTO `mac_sign` VALUES ('20', '97', '2021-04-18', '{\"points\":\"1\"}', '1618749758', '1618749758');
INSERT INTO `mac_sign` VALUES ('21', '193', '2022-01-24', '{\"points\":\"5\"}', '1643038808', '1643038808');
INSERT INTO `mac_sign` VALUES ('22', '194', '2022-01-28', '{\"points\":\"5\"}', '1643361656', '1643361656');
INSERT INTO `mac_sign` VALUES ('23', '194', '2022-01-29', '{\"points\":\"5\"}', '1643392880', '1643392880');
INSERT INTO `mac_sign` VALUES ('24', '200', '2022-01-29', '{\"points\":\"5\"}', '1643432753', '1643432753');
INSERT INTO `mac_sign` VALUES ('25', '202', '2022-01-31', '{\"points\":\"1\"}', '1643608934', '1643608934');
INSERT INTO `mac_sign` VALUES ('26', '194', '2022-02-02', '{\"points\":\"1\"}', '1643771476', '1643771476');
INSERT INTO `mac_sign` VALUES ('27', '209', '2022-02-02', '{\"points\":\"1\"}', '1643816388', '1643816388');
INSERT INTO `mac_sign` VALUES ('28', '217', '2022-02-03', '{\"points\":\"1\"}', '1643831968', '1643831968');
INSERT INTO `mac_sign` VALUES ('29', '220', '2022-02-03', '{\"points\":\"1\"}', '1643860233', '1643860233');
INSERT INTO `mac_sign` VALUES ('30', '224', '2022-02-07', '{\"points\":\"1\"}', '1644248839', '1644248839');
INSERT INTO `mac_sign` VALUES ('31', '226', '2022-02-07', '{\"points\":\"1\"}', '1644249454', '1644249454');
INSERT INTO `mac_sign` VALUES ('32', '223', '2022-02-08', '{\"points\":\"1\"}', '1644249890', '1644249890');
INSERT INTO `mac_sign` VALUES ('33', '229', '2022-02-08', '{\"points\":\"1\"}', '1644254352', '1644254352');
INSERT INTO `mac_sign` VALUES ('34', '233', '2022-02-08', '{\"points\":\"1\"}', '1644271630', '1644271630');
INSERT INTO `mac_sign` VALUES ('35', '227', '2022-02-08', '{\"points\":\"1\"}', '1644300244', '1644300244');
INSERT INTO `mac_sign` VALUES ('36', '238', '2022-02-10', '{\"points\":\"5\"}', '1644474788', '1644474788');
INSERT INTO `mac_sign` VALUES ('37', '241', '2022-02-10', '{\"points\":\"5\"}', '1644488942', '1644488942');
INSERT INTO `mac_sign` VALUES ('38', '243', '2022-02-10', '{\"points\":\"5\"}', '1644500633', '1644500633');

-- -----------------------------
-- Table structure for `mac_tmpvod`
-- -----------------------------
DROP TABLE IF EXISTS `mac_tmpvod`;
CREATE TABLE `mac_tmpvod` (
  `id1` int(10) unsigned DEFAULT NULL,
  `name1` varchar(255) NOT NULL DEFAULT '',
  `name_type` varchar(291) NOT NULL DEFAULT '',
  `tid1` smallint(6) NOT NULL DEFAULT '0',
  `year1` varchar(10) NOT NULL DEFAULT '',
  `area1` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_topic`
-- -----------------------------
DROP TABLE IF EXISTS `mac_topic`;
CREATE TABLE `mac_topic` (
  `topic_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `topic_name` varchar(255) NOT NULL DEFAULT '',
  `topic_en` varchar(255) NOT NULL DEFAULT '',
  `topic_sub` varchar(255) NOT NULL DEFAULT '',
  `topic_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `topic_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `topic_letter` char(1) NOT NULL DEFAULT '',
  `topic_color` varchar(6) NOT NULL DEFAULT '',
  `topic_tpl` varchar(30) NOT NULL DEFAULT '',
  `topic_type` varchar(255) NOT NULL DEFAULT '',
  `topic_pic` varchar(255) NOT NULL DEFAULT '',
  `topic_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `topic_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `topic_key` varchar(255) NOT NULL DEFAULT '',
  `topic_des` varchar(255) NOT NULL DEFAULT '',
  `topic_title` varchar(255) NOT NULL DEFAULT '',
  `topic_blurb` varchar(255) NOT NULL DEFAULT '',
  `topic_remarks` varchar(100) NOT NULL DEFAULT '',
  `topic_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `topic_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `topic_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_score_num` smallint(6) unsigned NOT NULL DEFAULT '0',
  `topic_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_time` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_tag` varchar(255) NOT NULL DEFAULT '',
  `topic_rel_vod` text,
  `topic_rel_art` text,
  `topic_content` text,
  `topic_extend` text,
  PRIMARY KEY (`topic_id`) USING BTREE,
  KEY `topic_sort` (`topic_sort`) USING BTREE,
  KEY `topic_level` (`topic_level`) USING BTREE,
  KEY `topic_score` (`topic_score`) USING BTREE,
  KEY `topic_score_all` (`topic_score_all`) USING BTREE,
  KEY `topic_score_num` (`topic_score_num`) USING BTREE,
  KEY `topic_hits` (`topic_hits`) USING BTREE,
  KEY `topic_hits_day` (`topic_hits_day`) USING BTREE,
  KEY `topic_hits_week` (`topic_hits_week`) USING BTREE,
  KEY `topic_hits_month` (`topic_hits_month`) USING BTREE,
  KEY `topic_time_add` (`topic_time_add`) USING BTREE,
  KEY `topic_time` (`topic_time`) USING BTREE,
  KEY `topic_time_hits` (`topic_time_hits`) USING BTREE,
  KEY `topic_name` (`topic_name`) USING BTREE,
  KEY `topic_en` (`topic_en`) USING BTREE,
  KEY `topic_up` (`topic_up`) USING BTREE,
  KEY `topic_down` (`topic_down`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP专题';

-- -----------------------------
-- Records of `mac_topic`
-- -----------------------------
INSERT INTO `mac_topic` VALUES ('2', '成龙专辑', 'yingyuandapian', '', '1', '0', '', '', 'detail.html', '电影', 'https://img2.doubanio.com/view/photo/l/public/p2005944092.webp', 'https://img2.doubanio.com/view/photo/l/public/p2005944092.webp', 'https://img2.doubanio.com/view/photo/l/public/p2005944092.webp', '', '', '', '小编推荐，院线大片，各种精彩电影', '', '0', '536', '309', '10.0', '443', '98', '7324', '81', '787', '4192', '1644501583', '1577460719', '0', '0', '', '425877,425715,425341,425275,424863,414331,424623,424591,424584,424429,424280,400282,406433,418819,403474,411486,400596,419067,398308,415694', '', '<p>新年快乐~小编整理了18部春节期间观看的电影。窝在被子里一个人看或者和伴侣和家人看都很适合哦~赶紧看起来吧~</p>', '');
INSERT INTO `mac_topic` VALUES ('6', '李连杰专辑', '李连杰专辑', '', '1', '0', '', '', 'detail.html', '电影', 'https://img2.doubanio.com/view/photo/l/public/p2212436592.webp', 'https://img2.doubanio.com/view/photo/l/public/p2212436592.webp', 'https://img2.doubanio.com/view/photo/l/public/p2212436592.webp', '', '', '', '李连杰连续五年获全国武术比赛的冠军，被北京市体委授予特等功，还被评为“勇攀高峰的突击手”，是七十年代武术界的常胜将军。也被称中华武术的第一高手。1979年，在第四届全运会上创造一人夺得5块金牌的奇迹后后逐渐淡出武术圈', '', '0', '0', '0', '0.0', '0', '0', '0', '0', '0', '0', '1644501817', '1644501693', '0', '0', '', '425759,425640,425355,424832,392413,416359,411486,416888,413863,409537,403745,417488,398761,418822,394518,398745,397646,422758,422276,421968', '', '<p>李连杰连续五年获全国武术比赛的冠军，被北京市体委授予特等功，还被评为“勇攀高峰的突击手”，是七十年代武术界的常胜将军。也被称中华武术的第一高手....</p>', '');
INSERT INTO `mac_topic` VALUES ('3', '林正英专辑', 'remenjuji', '', '1', '0', '', '', 'detail.html', '电视剧', 'https://i0.hdslb.com/bfs/article/f39564c9366a2b2c64100a6ed2dbd270ee71f9be.jpg', 'https://i0.hdslb.com/bfs/article/f39564c9366a2b2c64100a6ed2dbd270ee71f9be.jpg', 'https://i0.hdslb.com/bfs/article/f39564c9366a2b2c64100a6ed2dbd270ee71f9be.jpg', '', '', '', '热门剧集展播', '', '0', '74', '232', '5.0', '76', '46', '8007', '249', '543', '4640', '1644501789', '1577537633', '0', '0', '', '426170,425966,424491,423845,423511,423472,397708,400709,397294,399082,398771,416066,422388,422203,401253,416564,414061,410566,410062,409269,408901', '', '<p>林正英，香港著名动作演员和武术指导。小时候在粉菊花师傅的戏班中学习京剧表演，后来凭借一身好功夫进入电影圈做龙虎武师和武术指导，...<br/></p>', '');
INSERT INTO `mac_topic` VALUES ('7', '电台直播专区', 'diantaizhibozhuanqu', '', '1', '0', '', '', 'detail.html', '电影', 'https://hbimg.huabanimg.com/1ebd228820c35e0dcff34e2fba69ca417dd9d20cfc03-4G4tDj_fw1200', 'https://hbimg.huabanimg.com/1ebd228820c35e0dcff34e2fba69ca417dd9d20cfc03-4G4tDj_fw1200', 'https://hbimg.huabanimg.com/1ebd228820c35e0dcff34e2fba69ca417dd9d20cfc03-4G4tDj_fw1200', '', '', '', '', '', '0', '0', '0', '0.0', '0', '0', '0', '0', '0', '0', '1644502064', '1644502064', '0', '0', '', '426170,426168,426175,426174,426173,426172,426171,426169,426167', '', '', '');

-- -----------------------------
-- Table structure for `mac_type`
-- -----------------------------
DROP TABLE IF EXISTS `mac_type`;
CREATE TABLE `mac_type` (
  `type_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(60) NOT NULL DEFAULT '',
  `type_en` varchar(60) NOT NULL DEFAULT '',
  `type_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_mid` smallint(6) unsigned NOT NULL DEFAULT '1',
  `type_pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `type_tpl` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_list` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_detail` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_play` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_down` varchar(30) NOT NULL DEFAULT '',
  `type_key` varchar(255) NOT NULL DEFAULT '',
  `type_des` varchar(255) NOT NULL DEFAULT '',
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_union` varchar(255) NOT NULL DEFAULT '',
  `type_extend` text,
  `type_logo` varchar(255) NOT NULL DEFAULT '',
  `type_pic` varchar(255) NOT NULL DEFAULT '',
  `type_jumpurl` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`type_id`) USING BTREE,
  KEY `type_sort` (`type_sort`) USING BTREE,
  KEY `type_pid` (`type_pid`) USING BTREE,
  KEY `type_name` (`type_name`) USING BTREE,
  KEY `type_en` (`type_en`) USING BTREE,
  KEY `type_mid` (`type_mid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='APP分类';

-- -----------------------------
-- Records of `mac_type`
-- -----------------------------
INSERT INTO `mac_type` VALUES ('1', '电影', 'dianying', '1', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '电影,电影大全,电影天堂,最新电影,好看的电影,电影排行榜', '为您提供更新电影、好看的电影排行榜及电影迅雷下载，免费在线观看伦理电影、动作片、喜剧片、爱情片、搞笑片等全新电影。', '电影', '', '{\"class\":\"\\u534e\\u8bed,\\u5bb6\\u5ead,\\u559c\\u5267,\\u52a8\\u4f5c,\\u7231\\u60c5,\\u60ca\\u609a,\\u6050\\u6016\\u7247,\\u72af\\u7f6a,\\u5192\\u9669,\\u79d1\\u5e7b,\\u60ac\\u7591,\\u5267\\u60c5,\\u52a8\\u753b,\\u6b66\\u4fa0,\\u6218\\u4e89,\\u6b4c\\u821e,\\u5947\\u5e7b,\\u4f20\\u8bb0,\\u8b66\\u532a,\\u5386\\u53f2,\\u8fd0\\u52a8,\\u4f26\\u7406,\\u707e\\u96be,\\u897f\\u90e8,\\u9b54\\u5e7b,\\u67aa\\u6218,\\u6050\\u6016,\\u8bb0\\u5f55\",\"area\":\"\\u4e2d\\u56fd,\\u5185\\u5730,\\u5927\\u9646,\\u7f8e\\u56fd,\\u9999\\u6e2f,\\u97e9\\u56fd,\\u82f1\\u56fd,\\u53f0\\u6e7e,\\u65e5\\u672c,\\u6cd5\\u56fd,\\u610f\\u5927\\u5229,\\u5fb7\\u56fd,\\u897f\\u73ed\\u7259,\\u6cf0\\u56fd,\\u5176\\u5b83\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u6cd5\\u8bed,\\u5fb7\\u8bed,\\u5176\\u5b83\",\"year\":\"2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\\u738b\\u5b9d\\u5f3a,\\u9ec4\\u6e24,\\u5468\\u8fc5,\\u5468\\u51ac\\u96e8,\\u8303\\u51b0\\u51b0,\\u9648\\u5b66\\u51ac,\\u9648\\u4f1f\\u9706,\\u90ed\\u91c7\\u6d01,\\u9093\\u8d85,\\u6210\\u9f99,\\u845b\\u4f18,\\u6797\\u6b63\\u82f1,\\u5f20\\u5bb6\\u8f89,\\u6881\\u671d\\u4f1f,\\u5f90\\u5ce5,\\u90d1\\u607a,\\u5434\\u5f66\\u7956,\\u5218\\u5fb7\\u534e,\\u5468\\u661f\\u9a70,\\u6797\\u9752\\u971e,\\u5468\\u6da6\\u53d1,\\u674e\\u8fde\\u6770,\\u7504\\u5b50\\u4e39,\\u53e4\\u5929\\u4e50,\\u6d2a\\u91d1\\u5b9d,\\u59da\\u6668,\\u502a\\u59ae,\\u9ec4\\u6653\\u660e,\\u5f6d\\u4e8e\\u664f,\\u6c64\\u552f,\\u9648\\u5c0f\\u6625\",\"director\":\"\\u51af\\u5c0f\\u521a,\\u5f20\\u827a\\u8c0b,\\u5434\\u5b87\\u68ee,\\u9648\\u51ef\\u6b4c,\\u5f90\\u514b,\\u738b\\u5bb6\\u536b,\\u59dc\\u6587,\\u5468\\u661f\\u9a70,\\u674e\\u5b89\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248\"}', '', '', '');
INSERT INTO `mac_type` VALUES ('2', '连续剧', 'lianxuju', '2', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '电视剧,最新电视剧,好看的电视剧,热播电视剧,电视剧在线观看', '为您提供2018新电视剧排行榜，韩国电视剧、泰国电视剧、香港TVB全新电视剧排行榜、好看的电视剧等热播电视剧排行榜，并提供免费高清电视剧下载及在线观看。', '电视剧', '', '{\"class\":\"\\u53e4\\u88c5,\\u559c\\u5267,\\u5076\\u50cf,\\u5bb6\\u5ead,\\u9752\\u6625,\\u8b66\\u532a,\\u8a00\\u60c5,\\u519b\\u4e8b,\\u6b66\\u4fa0,\\u60ac\\u7591,\\u5386\\u53f2,\\u519c\\u6751,\\u90fd\\u5e02,\\u795e\\u8bdd,\\u79d1\\u5e7b,\\u5c11\\u513f,\\u641e\\u7b11,\\u8c0d\\u6218,\\u6218\\u4e89,\\u5e74\\u4ee3,\\u72af\\u7f6a,\\u6050\\u6016,\\u60ca\\u609a,\\u7231\\u60c5,\\u5267\\u60c5,\\u5947\\u5e7b\",\"area\":\"\\u4e2d\\u56fd,\\u5185\\u5730,\\u5927\\u9646,\\u97e9\\u56fd,\\u9999\\u6e2f,\\u53f0\\u6e7e,\\u65e5\\u672c,\\u7f8e\\u56fd,\\u6cf0\\u56fd,\\u82f1\\u56fd,\\u65b0\\u52a0\\u5761,\\u5176\\u4ed6,\\u9999\\u6e2f\\u5730\\u533a\",\"lang\":\"\\u666e\\u901a\\u8bdd,\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\\u738b\\u5b9d\\u5f3a,\\u80e1\\u6b4c,\\u970d\\u5efa\\u534e,\\u8d75\\u4e3d\\u9896,\\u5218\\u6d9b,\\u5218\\u8bd7\\u8bd7,\\u9648\\u4f1f\\u9706,\\u5434\\u5947\\u9686,\\u9646\\u6bc5,\\u5510\\u5ae3,\\u5173\\u6653\\u5f64,\\u5b59\\u4fea,\\u674e\\u6613\\u5cf0,\\u5f20\\u7ff0,\\u674e\\u6668,\\u8303\\u51b0\\u51b0,\\u6797\\u5fc3\\u5982,\\u6587\\u7ae0,\\u9a6c\\u4f0a\\u740d,\\u4f5f\\u5927\\u4e3a,\\u5b59\\u7ea2\\u96f7,\\u9648\\u5efa\\u658c,\\u674e\\u5c0f\\u7490\",\"director\":\"\\u5f20\\u7eaa\\u4e2d,\\u674e\\u5c11\\u7ea2,\\u5218\\u6c5f,\\u5b54\\u7b19,\\u5f20\\u9ece,\\u5eb7\\u6d2a\\u96f7,\\u9ad8\\u5e0c\\u5e0c,\\u80e1\\u73ab,\\u8d75\\u5b9d\\u521a,\\u90d1\\u6653\\u9f99\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248\"}', '', '', '');
INSERT INTO `mac_type` VALUES ('3', '综艺', 'zongyi', '4', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '综艺,综艺节目,最新综艺节目,综艺节目排行榜', '为您提供新综艺节目、好看的综艺节目排行榜，免费高清在线观看选秀、情感、访谈、搞笑、真人秀、脱口秀等热门综艺节目。', '综艺', '', '{\"class\":\"\\u660e\\u661f,\\u771f\\u4eba\\u79c0,\\u8bbf\\u8c08,\\u60c5\\u611f,\\u9009\\u79c0,\\u65c5\\u6e38,\\u7f8e\\u98df,\\u53e3\\u79c0,\\u66f2\\u827a,\\u641e\\u7b11,\\u6e38\\u620f,\\u6b4c\\u821e,\\u751f\\u6d3b,\\u97f3\\u4e50,\\u65f6\\u5c1a,\\u76ca\\u667a,\\u804c\\u573a,\\u5c11\\u513f,\\u7eaa\\u5b9e,\\u76db\\u4f1a\",\"area\":\"\\u4e2d\\u56fd,\\u5185\\u5730,\\u5927\\u9646,\\u97e9\\u56fd,\\u9999\\u6e2f,\\u53f0\\u6e7e,\\u7f8e\\u56fd,\\u5176\\u5b83\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\\u4f55\\u7085,\\u6c6a\\u6db5,\\u8c22\\u5a1c,\\u5468\\u7acb\\u6ce2,\\u9648\\u9c81\\u8c6b,\\u5b5f\\u975e,\\u674e\\u9759,\\u6731\\u519b,\\u6731\\u4e39,\\u534e\\u5c11,\\u90ed\\u5fb7\\u7eb2,\\u6768\\u6f9c\",\"director\":\"\\u51af\\u5c0f\\u521a,\\u5f20\\u827a\\u8c0b,\\u5434\\u5b87\\u68ee,\\u9648\\u51ef\\u6b4c,\\u5f90\\u514b,\\u738b\\u5bb6\\u536b,\\u59dc\\u6587,\\u5468\\u661f\\u9a70,\\u674e\\u5b89\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248\"}', '', '', '');
INSERT INTO `mac_type` VALUES ('4', '动漫', 'dongman', '3', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '动漫,动漫大全,最新动漫,好看的动漫,日本动漫,动漫排行榜', '为您提供新动漫、好看的动漫排行榜，免费高清在线观看热血动漫、卡通动漫、新番动漫、百合动漫、搞笑动漫、国产动漫、动漫电影等热门动漫。', '动画片', '', '{\"class\":\"\\u70ed\\u8840,\\u79d1\\u5e7b,\\u63a8\\u7406,\\u641e\\u7b11,\\u5192\\u9669,\\u6821\\u56ed,\\u52a8\\u4f5c,\\u673a\\u6218,\\u8fd0\\u52a8,\\u6218\\u4e89,\\u5c11\\u5e74,\\u5c11\\u5973,\\u793e\\u4f1a,\\u539f\\u521b,\\u4eb2\\u5b50,\\u76ca\\u667a,\\u52b1\\u5fd7,\\u5176\\u4ed6\",\"area\":\"\\u4e2d\\u56fd,\\u5185\\u5730,\\u5927\\u9646,\\u65e5\\u672c,\\u6b27\\u7f8e,\\u5176\\u4ed6\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\\u738b\\u5b9d\\u5f3a,\\u9ec4\\u6e24,\\u5468\\u8fc5,\\u5468\\u51ac\\u96e8,\\u8303\\u51b0\\u51b0,\\u9648\\u5b66\\u51ac,\\u9648\\u4f1f\\u9706,\\u90ed\\u91c7\\u6d01,\\u9093\\u8d85,\\u6210\\u9f99,\\u845b\\u4f18,\\u6797\\u6b63\\u82f1,\\u5f20\\u5bb6\\u8f89,\\u6881\\u671d\\u4f1f,\\u5f90\\u5ce5,\\u90d1\\u607a,\\u5434\\u5f66\\u7956,\\u5218\\u5fb7\\u534e,\\u5468\\u661f\\u9a70,\\u6797\\u9752\\u971e,\\u5468\\u6da6\\u53d1,\\u674e\\u8fde\\u6770,\\u7504\\u5b50\\u4e39,\\u53e4\\u5929\\u4e50,\\u6d2a\\u91d1\\u5b9d,\\u59da\\u6668,\\u502a\\u59ae,\\u9ec4\\u6653\\u660e,\\u5f6d\\u4e8e\\u664f,\\u6c64\\u552f,\\u9648\\u5c0f\\u6625\",\"director\":\"\\u51af\\u5c0f\\u521a,\\u5f20\\u827a\\u8c0b,\\u5434\\u5b87\\u68ee,\\u9648\\u51ef\\u6b4c,\\u5f90\\u514b,\\u738b\\u5bb6\\u536b,\\u59dc\\u6587,\\u5468\\u661f\\u9a70,\\u674e\\u5b89\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"TV\\u7248,\\u7535\\u5f71\\u7248,OVA\\u7248,\\u771f\\u4eba\\u7248\"}', '', '', '');
INSERT INTO `mac_type` VALUES ('33', '纪录片', 'jilupian', '8', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\\u7f8e\\u98df,\\u65c5\\u6e38,\\u52a8\\u7269\\u4e16\\u754c,\\u5386\\u53f2,\\u79d1\\u5b66\",\"area\":\"\\u5927\\u9646,\\u7f8e\\u56fd,\\u9999\\u6e2f,\\u97e9\\u56fd,\\u82f1\\u56fd,\\u53f0\\u6e7e,\\u65e5\\u672c,\\u6cd5\\u56fd,\\u610f\\u5927\\u5229,\\u5fb7\\u56fd,\\u897f\\u73ed\\u7259,\\u6cf0\\u56fd,\\u5176\\u5b83\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u6cd5\\u8bed,\\u5fb7\\u8bed,\\u5176\\u5b83\",\"year\":\"2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\\u6cb3\\u5357\\u5b9e\\u91cc,\\u7f8e\\u8c37\\u6731\\u91cc,\\u7acb\\u82b1\\u7f8e\\u51c9\",\"director\":\"\\u51af\\u5c0f\\u521a,\\u5f20\\u827a\\u8c0b,\\u5434\\u5b87\\u68ee,\\u9648\\u51ef\\u6b4c,\\u5f90\\u514b,\\u738b\\u5bb6\\u536b,\\u59dc\\u6587,\\u5468\\u661f\\u9a70,\\u674e\\u5b89\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248\"}', '', '', '');
INSERT INTO `mac_type` VALUES ('34', '电视台', 'dianshitai', '5', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\\u4e2d\\u592e\\u53f0,\\u7701\\u53f0,\\u5730\\u65b9\\u53f0,\\u9999\\u6e2f\\u53f0,\\u53f0\\u6e7e\\u53f0,\\u4e9a\\u6d32\\u53f0,\\u6b27\\u7f8e\\u53f0\",\"area\":\"\\u5927\\u9646,\\u7f8e\\u56fd,\\u9999\\u6e2f,\\u97e9\\u56fd,\\u82f1\\u56fd,\\u53f0\\u6e7e,\\u65e5\\u672c,\\u6cd5\\u56fd,\\u610f\\u5927\\u5229,\\u5fb7\\u56fd,\\u897f\\u73ed\\u7259,\\u6cf0\\u56fd,\\u5176\\u5b83\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u6cd5\\u8bed,\\u5fb7\\u8bed,\\u5176\\u5b83\",\"year\":\"2025,2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\",\"director\":\"\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248,1080P\"}', '', '', '');

-- -----------------------------
-- Table structure for `mac_ulog`
-- -----------------------------
DROP TABLE IF EXISTS `mac_ulog`;
CREATE TABLE `mac_ulog` (
  `ulog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_mid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ulog_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ulog_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_sid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ulog_nid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `ulog_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `ulog_time` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_end_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ulog_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `ulog_mid` (`ulog_mid`) USING BTREE,
  KEY `ulog_type` (`ulog_type`) USING BTREE,
  KEY `ulog_rid` (`ulog_rid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;


-- -----------------------------
-- Table structure for `mac_user`
-- -----------------------------
DROP TABLE IF EXISTS `mac_user`;
CREATE TABLE `mac_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(30) DEFAULT '',
  `user_pwd` varchar(32) DEFAULT '',
  `user_nick_name` varchar(30) NOT NULL DEFAULT '',
  `user_qq` varchar(16) NOT NULL DEFAULT '',
  `user_email` varchar(30) NOT NULL DEFAULT '',
  `user_phone` varchar(16) NOT NULL DEFAULT '',
  `user_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_portrait` varchar(100) NOT NULL DEFAULT '',
  `user_portrait_thumb` varchar(100) NOT NULL DEFAULT '',
  `user_openid_qq` varchar(40) NOT NULL DEFAULT '',
  `user_openid_weixin` varchar(40) NOT NULL DEFAULT '',
  `user_question` varchar(255) NOT NULL DEFAULT '',
  `user_answer` varchar(255) NOT NULL DEFAULT '',
  `user_points` int(10) unsigned NOT NULL DEFAULT '0',
  `user_points_froze` int(10) unsigned NOT NULL DEFAULT '0',
  `user_reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_reg_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_last_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_num` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_extend` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_random` varchar(32) NOT NULL DEFAULT '',
  `user_end_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_pid_2` int(10) unsigned NOT NULL DEFAULT '0',
  `user_pid_3` int(10) unsigned NOT NULL DEFAULT '0',
  `is_agents` int(11) NOT NULL DEFAULT '0',
  `user_gold` int(8) NOT NULL DEFAULT '0' COMMENT '用户拥有金币',
  `view_times` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`) USING BTREE,
  KEY `type_id` (`group_id`) USING BTREE,
  KEY `user_name` (`user_name`) USING BTREE,
  KEY `user_reg_time` (`user_reg_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=245 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员用户数据';

-- -----------------------------
-- Records of `mac_user`
-- -----------------------------
INSERT INTO `mac_user` VALUES ('194', '2', '18725911843', '97adfff7c7117fb6df57bd170ac06a28', '大河原唯梨', '', '', '', '1', 'upload/user/4/194.jpg', '', '', '', '', '', '27', '0', '1643361643', '453937890', '1643771381', '453904877', '1643768253', '453904877', '10', '0', '90af861994d947c93ca4f6d953c3c67f', '1644146263', '0', '0', '0', '1', '5000', '0');
INSERT INTO `mac_user` VALUES ('195', '2', '18725911842', '97adfff7c7117fb6df57bd170ac06a28', 'VHU5S', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1643368605', '453937890', '0', '0', '0', '0', '0', '0', '', '0', '194', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('196', '2', '18725911844', '97adfff7c7117fb6df57bd170ac06a28', 'L0CQV', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1643368616', '453937890', '0', '0', '0', '0', '0', '0', '', '0', '194', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('197', '2', '15002357894', '72312f95d5e8f9dab0d21e07389e566d', '7AT8N', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1643377426', '453937890', '1643377426', '453937890', '0', '0', '1', '0', 'd673c5944126f05f005545530333b9a9', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('198', '2', 'a2a52fa242c', '355f9f5b9f0e555dc0c47bc5ada8c07e', 'FE7JM', '', '', '', '1', '', '', '', '', '', '', '8', '0', '1643391016', '616042530', '1643803270', '2088153456', '1643391016', '616042530', '2', '0', '720ad65d4de96e1d1c3420a2d431920c', '0', '0', '0', '0', '1', '0', '0');
INSERT INTO `mac_user` VALUES ('199', '2', '18721792057', '87f783284430b81a11b6f8ea2b1d263b', 'P0ZYN', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1643424520', '989283672', '0', '0', '0', '0', '0', '0', '', '0', '194', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('200', '2', 'a19900d169d', '1eb4d9c58843f8b07741358915a93781', 'SC9MY', '', '', '', '1', '', '', '', '', '', '', '13', '0', '1643424629', '989283672', '1643769693', '989283672', '1643424629', '989283672', '2', '0', 'b019263091bc577662bef24f6f8020cd', '0', '0', '0', '0', '1', '0', '0');
INSERT INTO `mac_user` VALUES ('211', '2', '18569582259', '97adfff7c7117fb6df57bd170ac06a28', 'RAX9X', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643721848', '453904877', '1643721849', '453904877', '0', '0', '1', '0', '77e7bd2266a228dad76a9fc1e9ddc2f9', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('201', '2', '0699d67b091', 'b73d773657388d12bbef875f954f28ee', '8GRAF', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643575583', '0', '1643575583', '0', '0', '0', '1', '0', '7f75917e2505bcde461b438f32e75ddb', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('202', '2', '5a2c0a221d9', 'af94d0a5eb508539863cf4581866e2bd', 'HPS6U', '', '', '', '1', '', '', '', '', '', '', '2', '0', '1643589670', '453904877', '1643589670', '453904877', '0', '0', '1', '0', 'd5f30d2c37c505b40727c3bfd1956634', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('203', '2', 'a7642277629', 'bc2734b37c81c9549cc0a201bfa391bf', 'Y5KXO', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643593448', '0', '1643593448', '0', '0', '0', '1', '0', 'f1005b176d425b2473ef6b452c93c41e', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('204', '2', '18725911849', '97adfff7c7117fb6df57bd170ac06a28', 'UV3PK', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643704012', '453904877', '1643709572', '453904877', '1643704014', '453904877', '2', '0', 'fce4853f89fa9f21c050787477549313', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('205', '2', '18725911850', '97adfff7c7117fb6df57bd170ac06a28', '7WCUN', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643706431', '453904877', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('206', '2', '18589963521', 'ed58f4d130f91bd989a67a98036fff10', 'Z4YKO', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643709724', '453904877', '1643709725', '453904877', '0', '0', '1', '0', '5a6f4e5a8e1fd9e7edb7af27847bc838', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('207', '2', '18752635898', '212a1bebf6e6f7a2249fbd266dadeff7', 'CODCF', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643709785', '453904877', '1643709787', '453904877', '0', '0', '1', '0', '6cbb3738fbcb986c847dc1b2d2358acc', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('208', '2', '18589963523', '3a0919e9f04106024a158a425099088b', 'PHKBY', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643710006', '453904877', '1643710007', '453904877', '0', '0', '1', '0', 'da76c57b0106186a2a3902a1314227cd', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('209', '2', 'f59ea9f365a', 'c3cd90ac9098c9169e51f10dc631c495', 'HVP2Y', '', '', '', '1', '', '', '', '', '', '', '2', '0', '1643713216', '453904877', '1643816323', '453904877', '1643713216', '453904877', '2', '0', '028210fe97559e8a932e16df1c7d5300', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('210', '2', '15320401453', '97adfff7c7117fb6df57bd170ac06a28', '7FJSW', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643717937', '453904877', '1643717937', '453904877', '0', '0', '1', '0', '75229995fd5c536152158b21abc6f392', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('212', '2', '15809636985', 'a1acddbfbeb86c2389a781bebc589c13', 'OEUZG', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643723233', '453904877', '1643723233', '453904877', '0', '0', '1', '0', '962469da6e8a2f2b1439932ce13b863e', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('213', '2', '18725911852', '97adfff7c7117fb6df57bd170ac06a28', 'E0GQA', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643724759', '453904877', '1643724759', '453904877', '0', '0', '1', '0', '85cf08af32d281f712be9018e3ea9a0d', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('214', '2', '15289807486', 'a3b55ea4ee79e6f1b5ea057066653e34', 'NNAF2', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643727708', '453904877', '1643727712', '453904877', '0', '0', '1', '0', '776681c1dfc0f0330d7f8b52eb10fbda', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('215', '2', '18580809637', 'a1acddbfbeb86c2389a781bebc589c13', 'B8R5B', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643727957', '453904877', '1643727958', '453904877', '0', '0', '1', '0', 'cda705cccb09ef93f038fd2b63a75730', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('216', '2', 'b4c13f30bb9', 'd16ea2a5c64627306d40aa5a118f0d6f', 'HTU9V', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643822757', '2017866342', '1643822757', '2017866342', '0', '0', '1', '0', '2670bdd3348ce410919172deb1694ce7', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('217', '2', '2a7e3107e05', '7ef748da480c8557b339c154b2b253e4', 'FPILC', '', '', '', '1', '', '', '', '', '', '', '2', '0', '1643831799', '0', '1643831799', '0', '0', '0', '1', '0', 'fb8499759690e5d9e9f2c56bfc0b5d49', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('218', '2', '14163541555', 'fa7b448bad18685937f6cac7540262b4', '4A7TP', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643836129', '0', '1643836130', '0', '0', '0', '1', '0', '74f70e736344ba4d1c98cea78f4cf191', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('219', '2', '576a9810488', 'e68c7b7b59067edeb1f64e95b14f927c', 'T2B4U', '', '', '', '1', '', '', '', '', '', '', '1', '0', '1643851382', '2101578832', '1643851382', '2101578832', '0', '0', '1', '0', '386c7455f378657f29ea6007c4b9af03', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('220', '2', '8d63d26177f', '3878ad2e50f16654e639f771d5dac655', '8HO20', '', '', '', '1', '', '', '', '', '', '', '2', '0', '1643857066', '2111008610', '1643857066', '2111008610', '0', '0', '1', '0', 'ed8edce9e17a9f24b4013fd1fdb0efd2', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('193', '2', 'c20d45ddbee', 'a1acddbfbeb86c2389a781bebc589c13', 'E8X5D', '', '', '', '1', '', '', '', '', '', '', '0', '0', '1643038711', '453937890', '1643769534', '453904877', '1643769191', '453904877', '21', '0', '6cacf6b5c3fb4c7a36d8c30ee6fa6c2a', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('221', '2', '5e141fdce30', '275e7bca7c25f6c291e44bc8bfc366d5', 'VMHD6', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644236205', '453938028', '1644243504', '453938028', '1644236205', '453938028', '2', '0', 'b2be19446e8f6efe6e1d5dec6f17c522', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('222', '2', '8b75efa4eeb', 'fbdeae96161cb36c89311762a483a62a', 'Y7H0V', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644236540', '1894071500', '1644238310', '1894071500', '1644237663', '1894071500', '3', '0', '2a49bd6e741d99da20bf221fd71aad13', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('223', '2', '234a6c5f0fe', '68aab2c42c3dfa78a126c206ae295388', 'Z2T0A', '', '', '', '1', '', '', '', '', '', '', '13', '0', '1644247029', '1728485328', '1644247029', '1728485328', '0', '0', '1', '0', '1461389b2ee86545a3bedfc3a6f6b482', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('224', '2', 'b71a09b7a9b', '7aa5a85c172f8bc8ec48a6b38bfcb386', 'QGTG7', '', '', '', '1', '', '', '', '', '', '', '11', '0', '1644248632', '0', '1644248633', '0', '0', '0', '1', '0', 'ccf7a4dac07a2e707a58894d35e0b3f1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('225', '2', '5078703df45', 'ad3cd8017a4ce320c15889909def9830', 'IPOD2', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644248728', '1893734311', '1644248728', '1893734311', '0', '0', '1', '0', '8fff8fded98cbeaae9210155ecb3afdb', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('226', '2', 'bf896ee0e2c', 'ba02e147904f78d0fba62e5e6ee7fccf', 'ZD2LC', '', '', '', '1', '', '', '', '', '', '', '11', '0', '1644249443', '0', '1644249443', '0', '0', '0', '1', '0', '1c901aacad66ba95870e4cc39fd2b6f8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('227', '2', '9c236ab844d', 'c33434e91ddea66f24f1caacee2b67f5', '42ADL', '', '', '', '1', '', '', '', '', '', '', '11', '0', '1644250449', '454694308', '1644297394', '454694308', '1644250449', '454694308', '2', '0', '25de2c7823e31f9389109cd4bd194b7b', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('228', '2', '28a54bd9956', 'aab1bc6f477bbec11843a34f7d071168', 'QQADE', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644251728', '0', '1644251728', '0', '0', '0', '1', '0', '6a1b5551b65d5a90ee4f4e705b5b2644', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('229', '2', '00000000000', '2a881e267d6d70c87e68ccb988fd801f', 'UM30X', '', '', '', '1', '', '', '', '', '', '', '11', '0', '1644253818', '0', '1644547787', '467464539', '1644253818', '0', '2', '0', '93683453ee0a582ed4912d7df1f5a4c5', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('230', '2', '59f7f0b0f8c', 'b117f660cd92cbda3a9fd083d6cbcf84', 'YHZIV', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644254722', '2029208327', '1644254722', '2029208327', '0', '0', '1', '0', '496a33bf7431101f908dd75a4822f3b5', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('231', '2', 'afd57a5d077', '177fbfdeea4898525e0ac23fe214d926', '8VNVQ', '', '', '', '1', '', '', '', '', '', '', '11', '0', '1644256447', '1880222754', '1644256447', '1880222754', '0', '0', '1', '0', '316bdfba12021321b5b87fb096ceef42', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('232', '2', '11fcb714e9d', 'd7b0353c1ee8c84a0c907bffd5444c5b', 'Z940T', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644266680', '1880391631', '1644266680', '1880391631', '0', '0', '1', '0', '26da825b958b57e9ffeb4a23f9cfbd31', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('233', '2', '4de59a33af7', 'e033871c148dd0d846c00ff95f28dda4', 'VEXOI', '', '', '', '1', '', '', '', '', '', '', '11', '0', '1644271585', '1971869359', '1644271586', '1971869359', '0', '0', '1', '0', '7f695685e45d776e242e7ae8256ae0c7', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('234', '2', 'ecadac911a4', 'f823fc0c4540fce4dd2be6e224c1126e', '3FSHR', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644287471', '0', '1644287471', '0', '0', '0', '1', '0', '0860ee099fbb6adbff7f8cf6a8f95bd1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('235', '2', '34c6b2ecd9c', 'fe6a1c5ae04d31ebdf3a0661e6df51da', '06E28', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644287530', '1881468559', '1644287531', '1881468559', '0', '0', '1', '0', '4bfa6b86cf71bcc5041a8fbedda952f8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('236', '2', '016ff600243', '31bbd9c872114a07ac8ac0bc54971870', 'PST8F', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644292794', '1863348755', '1644292794', '1863348755', '0', '0', '1', '0', '9fe079d758d8fd2a973d041246a1c93e', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('237', '2', '8eb9dddb23c', 'f68d49494ba64ad87202ace3e6e22d88', 'UTLUY', '', '', '', '1', '', '', '', '', '', '', '10', '0', '1644294999', '0', '1644294999', '0', '0', '0', '1', '0', 'bdf9f819c87fdd7ceb2320b372bf82a7', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('238', '3', 'f0b9bedefc4', 'e485e325772818bb9faadbf42484f141', '多咪NO32O', '', '', '', '1', '', '', '', '', '', '', '8', '0', '1644473810', '1900921599', '1644492110', '455914694', '1644473810', '1900921599', '2', '0', '3812722b51a898a75e0369410413eb10', '1644561788', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('239', '2', '9356ea33e67', '2667a7f21697a2025a2c51403de8b8a5', '多咪O7RR5', '', '', '', '1', '', '', '', '', '', '', '100', '0', '1644486718', '1957880004', '1644486720', '1957880004', '0', '0', '1', '0', 'a44a7f78047044a1aa544ad6fb6a16c2', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('240', '2', 'dd07dd838bf', 'ea8ef167dd77f499aec0cab10784b806', '多咪5CJVM', '', '', '', '1', '', '', '', '', '', '', '100', '0', '1644487068', '663755059', '1644487068', '663755059', '0', '0', '1', '0', '445fd98215b6052c3ac78e0f5e25c2fe', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('241', '3', 'cd8efd99324', '391b3b2b69bed6f1eac29d83adbf5274', '多咪D0VB8', '', '', '', '1', '', '', '', '', '', '', '85', '0', '1644487586', '1873696330', '1644487586', '1873696330', '0', '0', '1', '0', '9fb54a1ac35808a49d1bf7d6fe97b759', '1645093737', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('242', '2', 'cf1f3f9a164', '1c195cf10a6c2a250dac1fbb5f2376f3', '多咪PTQIT', '', '', '', '1', '', '', '', '', '', '', '100', '0', '1644488081', '1973929647', '1644488081', '1973929647', '0', '0', '1', '0', '90f02a01e31f7626d5fcfae67b77720a', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('243', '2', '379b4ef4155', '170367a9941502b0590f6799f8781c9d', '多咪54FZ7', '', '', '', '1', '', '', '', '', '', '', '105', '0', '1644500456', '1974883719', '1644500456', '1974883719', '0', '0', '1', '0', '11b1cc1daec688863169f53b9ad191dd', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mac_user` VALUES ('244', '2', 'db66e46a0af', '315b01ed815d1b8fbdd598066015da31', '多咪BNRWV', '', '', '', '1', '', '', '', '', '', '', '100', '0', '1644547624', '1971867906', '1644547624', '1971867906', '0', '0', '1', '0', 'dcfea3e27e31053523737b089cf6c1d2', '0', '0', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `mac_view30m`
-- -----------------------------
DROP TABLE IF EXISTS `mac_view30m`;
CREATE TABLE `mac_view30m` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(11) DEFAULT NULL,
  `view_seconds` int(255) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `vod_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=567316 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_view30m`
-- -----------------------------
INSERT INTO `mac_view30m` VALUES ('567050', '1644509797', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567051', '1644509827', '120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567052', '1644509836', '180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567053', '1644509901', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567054', '1644509931', '120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567055', '1644509961', '180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567056', '1644509991', '240', '238', '');
INSERT INTO `mac_view30m` VALUES ('567057', '1644510021', '300', '238', '');
INSERT INTO `mac_view30m` VALUES ('567058', '1644510051', '360', '238', '');
INSERT INTO `mac_view30m` VALUES ('567059', '1644510081', '420', '238', '');
INSERT INTO `mac_view30m` VALUES ('567060', '1644510111', '480', '238', '');
INSERT INTO `mac_view30m` VALUES ('567061', '1644510141', '540', '238', '');
INSERT INTO `mac_view30m` VALUES ('567062', '1644510171', '600', '238', '');
INSERT INTO `mac_view30m` VALUES ('567063', '1644510201', '660', '238', '');
INSERT INTO `mac_view30m` VALUES ('567064', '1644510231', '720', '238', '');
INSERT INTO `mac_view30m` VALUES ('567065', '1644510261', '780', '238', '');
INSERT INTO `mac_view30m` VALUES ('567066', '1644510291', '840', '238', '');
INSERT INTO `mac_view30m` VALUES ('567067', '1644510321', '900', '238', '');
INSERT INTO `mac_view30m` VALUES ('567068', '1644510351', '960', '238', '');
INSERT INTO `mac_view30m` VALUES ('567069', '1644510381', '1020', '238', '');
INSERT INTO `mac_view30m` VALUES ('567070', '1644510411', '1080', '238', '');
INSERT INTO `mac_view30m` VALUES ('567071', '1644510441', '1140', '238', '');
INSERT INTO `mac_view30m` VALUES ('567072', '1644510471', '1200', '238', '');
INSERT INTO `mac_view30m` VALUES ('567073', '1644510501', '1260', '238', '');
INSERT INTO `mac_view30m` VALUES ('567074', '1644510531', '1320', '238', '');
INSERT INTO `mac_view30m` VALUES ('567075', '1644510561', '1380', '238', '');
INSERT INTO `mac_view30m` VALUES ('567076', '1644510591', '1440', '238', '');
INSERT INTO `mac_view30m` VALUES ('567077', '1644510621', '1500', '238', '');
INSERT INTO `mac_view30m` VALUES ('567078', '1644510651', '1560', '238', '');
INSERT INTO `mac_view30m` VALUES ('567079', '1644510681', '1620', '238', '');
INSERT INTO `mac_view30m` VALUES ('567080', '1644510711', '1680', '238', '');
INSERT INTO `mac_view30m` VALUES ('567081', '1644510741', '1740', '238', '');
INSERT INTO `mac_view30m` VALUES ('567082', '1644510771', '1800', '238', '');
INSERT INTO `mac_view30m` VALUES ('567083', '1644510801', '1860', '238', '');
INSERT INTO `mac_view30m` VALUES ('567084', '1644510831', '1920', '238', '');
INSERT INTO `mac_view30m` VALUES ('567085', '1644510861', '1980', '238', '');
INSERT INTO `mac_view30m` VALUES ('567086', '1644510891', '2040', '238', '');
INSERT INTO `mac_view30m` VALUES ('567087', '1644510921', '2100', '238', '');
INSERT INTO `mac_view30m` VALUES ('567088', '1644510951', '2160', '238', '');
INSERT INTO `mac_view30m` VALUES ('567089', '1644510981', '2220', '238', '');
INSERT INTO `mac_view30m` VALUES ('567090', '1644511011', '2280', '238', '');
INSERT INTO `mac_view30m` VALUES ('567091', '1644511041', '2340', '238', '');
INSERT INTO `mac_view30m` VALUES ('567092', '1644511071', '2400', '238', '');
INSERT INTO `mac_view30m` VALUES ('567093', '1644511101', '2460', '238', '');
INSERT INTO `mac_view30m` VALUES ('567094', '1644511131', '2520', '238', '');
INSERT INTO `mac_view30m` VALUES ('567095', '1644511161', '2580', '238', '');
INSERT INTO `mac_view30m` VALUES ('567096', '1644511191', '2640', '238', '');
INSERT INTO `mac_view30m` VALUES ('567097', '1644511221', '2700', '238', '');
INSERT INTO `mac_view30m` VALUES ('567098', '1644511251', '2760', '238', '');
INSERT INTO `mac_view30m` VALUES ('567099', '1644511281', '2820', '238', '');
INSERT INTO `mac_view30m` VALUES ('567100', '1644511311', '2880', '238', '');
INSERT INTO `mac_view30m` VALUES ('567101', '1644511341', '2940', '238', '');
INSERT INTO `mac_view30m` VALUES ('567102', '1644511371', '3000', '238', '');
INSERT INTO `mac_view30m` VALUES ('567103', '1644511401', '3060', '238', '');
INSERT INTO `mac_view30m` VALUES ('567104', '1644511431', '3120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567105', '1644511461', '3180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567106', '1644511491', '3240', '238', '');
INSERT INTO `mac_view30m` VALUES ('567107', '1644511521', '3300', '238', '');
INSERT INTO `mac_view30m` VALUES ('567108', '1644511551', '3360', '238', '');
INSERT INTO `mac_view30m` VALUES ('567109', '1644511581', '3420', '238', '');
INSERT INTO `mac_view30m` VALUES ('567110', '1644511611', '3480', '238', '');
INSERT INTO `mac_view30m` VALUES ('567111', '1644511641', '3540', '238', '');
INSERT INTO `mac_view30m` VALUES ('567112', '1644511671', '3600', '238', '');
INSERT INTO `mac_view30m` VALUES ('567113', '1644511701', '3660', '238', '');
INSERT INTO `mac_view30m` VALUES ('567114', '1644511731', '3720', '238', '');
INSERT INTO `mac_view30m` VALUES ('567115', '1644511761', '3780', '238', '');
INSERT INTO `mac_view30m` VALUES ('567116', '1644511791', '3840', '238', '');
INSERT INTO `mac_view30m` VALUES ('567117', '1644511821', '3900', '238', '');
INSERT INTO `mac_view30m` VALUES ('567118', '1644511851', '3960', '238', '');
INSERT INTO `mac_view30m` VALUES ('567119', '1644511881', '4020', '238', '');
INSERT INTO `mac_view30m` VALUES ('567120', '1644511911', '4080', '238', '');
INSERT INTO `mac_view30m` VALUES ('567121', '1644511941', '4140', '238', '');
INSERT INTO `mac_view30m` VALUES ('567122', '1644511971', '4200', '238', '');
INSERT INTO `mac_view30m` VALUES ('567123', '1644512001', '4260', '238', '');
INSERT INTO `mac_view30m` VALUES ('567124', '1644512031', '4320', '238', '');
INSERT INTO `mac_view30m` VALUES ('567125', '1644512061', '4380', '238', '');
INSERT INTO `mac_view30m` VALUES ('567126', '1644512091', '4440', '238', '');
INSERT INTO `mac_view30m` VALUES ('567127', '1644512121', '4500', '238', '');
INSERT INTO `mac_view30m` VALUES ('567128', '1644512151', '4560', '238', '');
INSERT INTO `mac_view30m` VALUES ('567129', '1644512181', '4620', '238', '');
INSERT INTO `mac_view30m` VALUES ('567130', '1644512211', '4680', '238', '');
INSERT INTO `mac_view30m` VALUES ('567131', '1644512241', '4740', '238', '');
INSERT INTO `mac_view30m` VALUES ('567132', '1644512271', '4800', '238', '');
INSERT INTO `mac_view30m` VALUES ('567133', '1644512301', '4860', '238', '');
INSERT INTO `mac_view30m` VALUES ('567134', '1644512331', '4920', '238', '');
INSERT INTO `mac_view30m` VALUES ('567135', '1644512361', '4980', '238', '');
INSERT INTO `mac_view30m` VALUES ('567136', '1644512391', '5040', '238', '');
INSERT INTO `mac_view30m` VALUES ('567137', '1644512421', '5100', '238', '');
INSERT INTO `mac_view30m` VALUES ('567138', '1644512451', '5160', '238', '');
INSERT INTO `mac_view30m` VALUES ('567139', '1644512481', '5220', '238', '');
INSERT INTO `mac_view30m` VALUES ('567140', '1644512511', '5280', '238', '');
INSERT INTO `mac_view30m` VALUES ('567141', '1644512541', '5340', '238', '');
INSERT INTO `mac_view30m` VALUES ('567142', '1644512571', '5400', '238', '');
INSERT INTO `mac_view30m` VALUES ('567143', '1644512601', '5460', '238', '');
INSERT INTO `mac_view30m` VALUES ('567144', '1644512631', '5520', '238', '');
INSERT INTO `mac_view30m` VALUES ('567145', '1644512661', '5580', '238', '');
INSERT INTO `mac_view30m` VALUES ('567146', '1644512691', '5640', '238', '');
INSERT INTO `mac_view30m` VALUES ('567147', '1644512721', '5700', '238', '');
INSERT INTO `mac_view30m` VALUES ('567148', '1644512751', '5760', '238', '');
INSERT INTO `mac_view30m` VALUES ('567149', '1644512781', '5820', '238', '');
INSERT INTO `mac_view30m` VALUES ('567150', '1644512811', '5880', '238', '');
INSERT INTO `mac_view30m` VALUES ('567151', '1644512841', '5940', '238', '');
INSERT INTO `mac_view30m` VALUES ('567152', '1644512871', '6000', '238', '');
INSERT INTO `mac_view30m` VALUES ('567153', '1644512901', '6060', '238', '');
INSERT INTO `mac_view30m` VALUES ('567154', '1644512931', '6120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567155', '1644512961', '6180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567156', '1644512991', '6240', '238', '');
INSERT INTO `mac_view30m` VALUES ('567157', '1644513021', '6300', '238', '');
INSERT INTO `mac_view30m` VALUES ('567158', '1644513051', '6360', '238', '');
INSERT INTO `mac_view30m` VALUES ('567159', '1644513081', '6420', '238', '');
INSERT INTO `mac_view30m` VALUES ('567160', '1644513111', '6480', '238', '');
INSERT INTO `mac_view30m` VALUES ('567161', '1644513141', '6540', '238', '');
INSERT INTO `mac_view30m` VALUES ('567162', '1644513171', '6600', '238', '');
INSERT INTO `mac_view30m` VALUES ('567163', '1644513201', '6660', '238', '');
INSERT INTO `mac_view30m` VALUES ('567164', '1644513231', '6720', '238', '');
INSERT INTO `mac_view30m` VALUES ('567165', '1644513261', '6780', '238', '');
INSERT INTO `mac_view30m` VALUES ('567166', '1644513291', '6840', '238', '');
INSERT INTO `mac_view30m` VALUES ('567167', '1644513321', '6900', '238', '');
INSERT INTO `mac_view30m` VALUES ('567168', '1644513351', '6960', '238', '');
INSERT INTO `mac_view30m` VALUES ('567169', '1644513381', '7020', '238', '');
INSERT INTO `mac_view30m` VALUES ('567170', '1644513411', '7080', '238', '');
INSERT INTO `mac_view30m` VALUES ('567171', '1644513441', '7140', '238', '');
INSERT INTO `mac_view30m` VALUES ('567172', '1644513471', '7200', '238', '');
INSERT INTO `mac_view30m` VALUES ('567173', '1644513501', '7260', '238', '');
INSERT INTO `mac_view30m` VALUES ('567174', '1644513531', '7320', '238', '');
INSERT INTO `mac_view30m` VALUES ('567175', '1644513561', '7380', '238', '');
INSERT INTO `mac_view30m` VALUES ('567176', '1644513591', '7440', '238', '');
INSERT INTO `mac_view30m` VALUES ('567177', '1644513621', '7500', '238', '');
INSERT INTO `mac_view30m` VALUES ('567178', '1644513651', '7560', '238', '');
INSERT INTO `mac_view30m` VALUES ('567179', '1644513681', '7620', '238', '');
INSERT INTO `mac_view30m` VALUES ('567180', '1644513711', '7680', '238', '');
INSERT INTO `mac_view30m` VALUES ('567181', '1644513741', '7740', '238', '');
INSERT INTO `mac_view30m` VALUES ('567182', '1644513771', '7800', '238', '');
INSERT INTO `mac_view30m` VALUES ('567183', '1644513801', '7860', '238', '');
INSERT INTO `mac_view30m` VALUES ('567184', '1644513831', '7920', '238', '');
INSERT INTO `mac_view30m` VALUES ('567185', '1644513861', '7980', '238', '');
INSERT INTO `mac_view30m` VALUES ('567186', '1644513891', '8040', '238', '');
INSERT INTO `mac_view30m` VALUES ('567187', '1644513921', '8100', '238', '');
INSERT INTO `mac_view30m` VALUES ('567188', '1644513951', '8160', '238', '');
INSERT INTO `mac_view30m` VALUES ('567189', '1644513981', '8220', '238', '');
INSERT INTO `mac_view30m` VALUES ('567190', '1644514011', '8280', '238', '');
INSERT INTO `mac_view30m` VALUES ('567191', '1644514041', '8340', '238', '');
INSERT INTO `mac_view30m` VALUES ('567192', '1644514071', '8400', '238', '');
INSERT INTO `mac_view30m` VALUES ('567193', '1644514101', '8460', '238', '');
INSERT INTO `mac_view30m` VALUES ('567194', '1644514131', '8520', '238', '');
INSERT INTO `mac_view30m` VALUES ('567195', '1644514161', '8580', '238', '');
INSERT INTO `mac_view30m` VALUES ('567196', '1644514191', '8640', '238', '');
INSERT INTO `mac_view30m` VALUES ('567197', '1644514221', '8700', '238', '');
INSERT INTO `mac_view30m` VALUES ('567198', '1644514251', '8760', '238', '');
INSERT INTO `mac_view30m` VALUES ('567199', '1644514281', '8820', '238', '');
INSERT INTO `mac_view30m` VALUES ('567200', '1644514311', '8880', '238', '');
INSERT INTO `mac_view30m` VALUES ('567201', '1644514341', '8940', '238', '');
INSERT INTO `mac_view30m` VALUES ('567202', '1644514371', '9000', '238', '');
INSERT INTO `mac_view30m` VALUES ('567203', '1644514401', '9060', '238', '');
INSERT INTO `mac_view30m` VALUES ('567204', '1644514431', '9120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567205', '1644514461', '9180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567206', '1644514491', '9240', '238', '');
INSERT INTO `mac_view30m` VALUES ('567207', '1644514521', '9300', '238', '');
INSERT INTO `mac_view30m` VALUES ('567208', '1644514551', '9360', '238', '');
INSERT INTO `mac_view30m` VALUES ('567209', '1644514581', '9420', '238', '');
INSERT INTO `mac_view30m` VALUES ('567210', '1644514611', '9480', '238', '');
INSERT INTO `mac_view30m` VALUES ('567211', '1644514641', '9540', '238', '');
INSERT INTO `mac_view30m` VALUES ('567212', '1644514671', '9600', '238', '');
INSERT INTO `mac_view30m` VALUES ('567213', '1644514701', '9660', '238', '');
INSERT INTO `mac_view30m` VALUES ('567214', '1644514731', '9720', '238', '');
INSERT INTO `mac_view30m` VALUES ('567215', '1644514761', '9780', '238', '');
INSERT INTO `mac_view30m` VALUES ('567216', '1644514791', '9840', '238', '');
INSERT INTO `mac_view30m` VALUES ('567217', '1644514821', '9900', '238', '');
INSERT INTO `mac_view30m` VALUES ('567218', '1644514851', '9960', '238', '');
INSERT INTO `mac_view30m` VALUES ('567219', '1644514881', '10020', '238', '');
INSERT INTO `mac_view30m` VALUES ('567220', '1644514911', '10080', '238', '');
INSERT INTO `mac_view30m` VALUES ('567221', '1644514941', '10140', '238', '');
INSERT INTO `mac_view30m` VALUES ('567222', '1644514971', '10200', '238', '');
INSERT INTO `mac_view30m` VALUES ('567223', '1644515001', '10260', '238', '');
INSERT INTO `mac_view30m` VALUES ('567224', '1644515031', '10320', '238', '');
INSERT INTO `mac_view30m` VALUES ('567225', '1644515061', '10380', '238', '');
INSERT INTO `mac_view30m` VALUES ('567226', '1644515091', '10440', '238', '');
INSERT INTO `mac_view30m` VALUES ('567227', '1644515121', '10500', '238', '');
INSERT INTO `mac_view30m` VALUES ('567228', '1644515151', '10560', '238', '');
INSERT INTO `mac_view30m` VALUES ('567229', '1644515181', '10620', '238', '');
INSERT INTO `mac_view30m` VALUES ('567230', '1644515211', '10680', '238', '');
INSERT INTO `mac_view30m` VALUES ('567231', '1644515241', '10740', '238', '');
INSERT INTO `mac_view30m` VALUES ('567232', '1644515271', '10800', '238', '');
INSERT INTO `mac_view30m` VALUES ('567233', '1644515301', '10860', '238', '');
INSERT INTO `mac_view30m` VALUES ('567234', '1644515331', '10920', '238', '');
INSERT INTO `mac_view30m` VALUES ('567235', '1644515361', '10980', '238', '');
INSERT INTO `mac_view30m` VALUES ('567236', '1644515391', '11040', '238', '');
INSERT INTO `mac_view30m` VALUES ('567237', '1644515421', '11100', '238', '');
INSERT INTO `mac_view30m` VALUES ('567238', '1644515451', '11160', '238', '');
INSERT INTO `mac_view30m` VALUES ('567239', '1644515481', '11220', '238', '');
INSERT INTO `mac_view30m` VALUES ('567240', '1644515511', '11280', '238', '');
INSERT INTO `mac_view30m` VALUES ('567241', '1644515541', '11340', '238', '');
INSERT INTO `mac_view30m` VALUES ('567242', '1644515571', '11400', '238', '');
INSERT INTO `mac_view30m` VALUES ('567243', '1644515601', '11460', '238', '');
INSERT INTO `mac_view30m` VALUES ('567244', '1644515631', '11520', '238', '');
INSERT INTO `mac_view30m` VALUES ('567245', '1644515661', '11580', '238', '');
INSERT INTO `mac_view30m` VALUES ('567246', '1644515691', '11640', '238', '');
INSERT INTO `mac_view30m` VALUES ('567247', '1644515721', '11700', '238', '');
INSERT INTO `mac_view30m` VALUES ('567248', '1644515751', '11760', '238', '');
INSERT INTO `mac_view30m` VALUES ('567249', '1644515781', '11820', '238', '');
INSERT INTO `mac_view30m` VALUES ('567250', '1644515811', '11880', '238', '');
INSERT INTO `mac_view30m` VALUES ('567251', '1644515841', '11940', '238', '');
INSERT INTO `mac_view30m` VALUES ('567252', '1644515871', '12000', '238', '');
INSERT INTO `mac_view30m` VALUES ('567253', '1644515901', '12060', '238', '');
INSERT INTO `mac_view30m` VALUES ('567254', '1644515931', '12120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567255', '1644515961', '12180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567256', '1644515991', '12240', '238', '');
INSERT INTO `mac_view30m` VALUES ('567257', '1644516021', '12300', '238', '');
INSERT INTO `mac_view30m` VALUES ('567258', '1644516051', '12360', '238', '');
INSERT INTO `mac_view30m` VALUES ('567259', '1644516081', '12420', '238', '');
INSERT INTO `mac_view30m` VALUES ('567260', '1644516111', '12480', '238', '');
INSERT INTO `mac_view30m` VALUES ('567261', '1644516141', '12540', '238', '');
INSERT INTO `mac_view30m` VALUES ('567262', '1644516171', '12600', '238', '');
INSERT INTO `mac_view30m` VALUES ('567263', '1644516201', '12660', '238', '');
INSERT INTO `mac_view30m` VALUES ('567264', '1644516231', '12720', '238', '');
INSERT INTO `mac_view30m` VALUES ('567265', '1644516261', '12780', '238', '');
INSERT INTO `mac_view30m` VALUES ('567266', '1644516291', '12840', '238', '');
INSERT INTO `mac_view30m` VALUES ('567267', '1644516321', '12900', '238', '');
INSERT INTO `mac_view30m` VALUES ('567268', '1644516351', '12960', '238', '');
INSERT INTO `mac_view30m` VALUES ('567269', '1644516381', '13020', '238', '');
INSERT INTO `mac_view30m` VALUES ('567270', '1644516411', '13080', '238', '');
INSERT INTO `mac_view30m` VALUES ('567271', '1644516441', '13140', '238', '');
INSERT INTO `mac_view30m` VALUES ('567272', '1644516471', '13200', '238', '');
INSERT INTO `mac_view30m` VALUES ('567273', '1644516501', '13260', '238', '');
INSERT INTO `mac_view30m` VALUES ('567274', '1644516531', '13320', '238', '');
INSERT INTO `mac_view30m` VALUES ('567275', '1644516561', '13380', '238', '');
INSERT INTO `mac_view30m` VALUES ('567276', '1644516591', '13440', '238', '');
INSERT INTO `mac_view30m` VALUES ('567277', '1644516621', '13500', '238', '');
INSERT INTO `mac_view30m` VALUES ('567278', '1644516651', '13560', '238', '');
INSERT INTO `mac_view30m` VALUES ('567279', '1644516681', '13620', '238', '');
INSERT INTO `mac_view30m` VALUES ('567280', '1644516711', '13680', '238', '');
INSERT INTO `mac_view30m` VALUES ('567281', '1644516741', '13740', '238', '');
INSERT INTO `mac_view30m` VALUES ('567282', '1644516771', '13800', '238', '');
INSERT INTO `mac_view30m` VALUES ('567283', '1644516801', '13860', '238', '');
INSERT INTO `mac_view30m` VALUES ('567284', '1644516831', '13920', '238', '');
INSERT INTO `mac_view30m` VALUES ('567285', '1644516893', '13980', '238', '');
INSERT INTO `mac_view30m` VALUES ('567286', '1644517033', '14040', '238', '');
INSERT INTO `mac_view30m` VALUES ('567287', '1644517063', '14100', '238', '');
INSERT INTO `mac_view30m` VALUES ('567288', '1644517093', '14160', '238', '');
INSERT INTO `mac_view30m` VALUES ('567289', '1644517123', '14220', '238', '');
INSERT INTO `mac_view30m` VALUES ('567290', '1644538168', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567291', '1644541503', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567292', '1644547867', '60', '229', '');
INSERT INTO `mac_view30m` VALUES ('567293', '1644547897', '120', '229', '');
INSERT INTO `mac_view30m` VALUES ('567294', '1644547927', '180', '229', '');
INSERT INTO `mac_view30m` VALUES ('567295', '1644547957', '240', '229', '');
INSERT INTO `mac_view30m` VALUES ('567296', '1644547987', '300', '229', '');
INSERT INTO `mac_view30m` VALUES ('567297', '1644548110', '120', '229', '');
INSERT INTO `mac_view30m` VALUES ('567298', '1644548140', '180', '229', '');
INSERT INTO `mac_view30m` VALUES ('567299', '1644548170', '240', '229', '');
INSERT INTO `mac_view30m` VALUES ('567300', '1644548200', '300', '229', '');
INSERT INTO `mac_view30m` VALUES ('567301', '1644548230', '360', '229', '');
INSERT INTO `mac_view30m` VALUES ('567302', '1644548260', '420', '229', '');
INSERT INTO `mac_view30m` VALUES ('567303', '1644548266', '480', '229', '');
INSERT INTO `mac_view30m` VALUES ('567304', '1644553306', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567305', '1644553329', '120', '238', '');
INSERT INTO `mac_view30m` VALUES ('567306', '1644553359', '180', '238', '');
INSERT INTO `mac_view30m` VALUES ('567307', '1644553389', '240', '238', '');
INSERT INTO `mac_view30m` VALUES ('567308', '1644553419', '300', '238', '');
INSERT INTO `mac_view30m` VALUES ('567309', '1644553449', '360', '238', '');
INSERT INTO `mac_view30m` VALUES ('567310', '1644553479', '420', '238', '');
INSERT INTO `mac_view30m` VALUES ('567311', '1644553509', '480', '238', '');
INSERT INTO `mac_view30m` VALUES ('567312', '1644553533', '540', '238', '');
INSERT INTO `mac_view30m` VALUES ('567313', '1644553635', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567314', '1644553956', '60', '238', '');
INSERT INTO `mac_view30m` VALUES ('567315', '1644553985', '120', '238', '');

-- -----------------------------
-- Table structure for `mac_visit`
-- -----------------------------
DROP TABLE IF EXISTS `mac_visit`;
CREATE TABLE `mac_visit` (
  `visit_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `visit_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `visit_ly` varchar(100) NOT NULL DEFAULT '',
  `visit_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`visit_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `visit_time` (`visit_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_vlog`
-- -----------------------------
DROP TABLE IF EXISTS `mac_vlog`;
CREATE TABLE `mac_vlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vod_id` int(11) DEFAULT NULL,
  `nid` varchar(200) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `percent` varchar(255) DEFAULT NULL,
  `last_view_time` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `curProgress` int(11) NOT NULL,
  `urlIndex` int(11) NOT NULL,
  `playSourceIndex` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=194 DEFAULT CHARSET=utf8 COMMENT='APP播放记录';

-- -----------------------------
-- Records of `mac_vlog`
-- -----------------------------
INSERT INTO `mac_vlog` VALUES ('77', '348964', '第1集', '优酷视频', '0.73', '1643816784', '194', '1908902', '0', '0');
INSERT INTO `mac_vlog` VALUES ('75', '281606', '双语字幕正片', '腾讯视频', '0.0', '1643805704', '194', '2054', '0', '0');
INSERT INTO `mac_vlog` VALUES ('100', '276690', '第1集', '芒果tv', '0.01', '1643818564', '209', '4151', '0', '0');
INSERT INTO `mac_vlog` VALUES ('94', '281606', '双语字幕正片', '腾讯视频', '0.01', '1643817983', '209', '6134', '0', '0');
INSERT INTO `mac_vlog` VALUES ('93', '284185', '正片', '腾讯视频', '0.01', '1643817249', '194', '46382', '0', '0');
INSERT INTO `mac_vlog` VALUES ('36', '339381', 'HD', '奇艺视频', '0.0', '1643511883', '194', '2916', '0', '0');
INSERT INTO `mac_vlog` VALUES ('37', '339538', 'HD', '芒果tv', '0.0', '1643511892', '194', '2176', '0', '0');
INSERT INTO `mac_vlog` VALUES ('38', '260297', '第5集', '腾讯视频', '0.01', '1643805663', '194', '19859', '4', '0');
INSERT INTO `mac_vlog` VALUES ('39', '260312', '第1集', '优酷视频', '0.0', '1643786526', '194', '8368', '0', '0');
INSERT INTO `mac_vlog` VALUES ('40', '260298', '第12集', '青豆片库', '0.0', '1643548668', '194', '8088', '11', '1');
INSERT INTO `mac_vlog` VALUES ('41', '260257', 'HD', '青豆片库', '0.0', '1643556706', '194', '17749', '0', '0');
INSERT INTO `mac_vlog` VALUES ('43', '265646', '第28集', '腾讯视频', '0.0', '1643575616', '201', '363', '27', '0');
INSERT INTO `mac_vlog` VALUES ('42', '265646', '第1集', '腾讯视频', '0.01', '1643556740', '194', '5346', '0', '0');
INSERT INTO `mac_vlog` VALUES ('14', '278541', '第1集', '芒果tv', '0.02', '1643377779', '197', '1804', '0', '0');
INSERT INTO `mac_vlog` VALUES ('15', '260311', '第1集', '腾讯视频', '0.0', '1643826542', '194', '1528', '0', '0');
INSERT INTO `mac_vlog` VALUES ('16', '265052', '第34集', '腾讯视频', '0.95', '1643780579', '194', '2680890', '33', '0');
INSERT INTO `mac_vlog` VALUES ('18', '260297', '第1集', '奇艺视频', '0.0', '1643432447', '200', '2127', '0', '1');
INSERT INTO `mac_vlog` VALUES ('19', '304528', 'HD中字', '青豆片库', '0.0', '1643425220', '200', '2585', '0', '0');
INSERT INTO `mac_vlog` VALUES ('20', '316936', '第预告集', '优酷视频', '0.53', '1643425351', '200', '38468', '0', '0');
INSERT INTO `mac_vlog` VALUES ('21', '324921', '高清', '腾讯视频', '0.0', '1643425386', '200', '19317', '0', '0');
INSERT INTO `mac_vlog` VALUES ('22', '324978', '高清', '腾讯视频', '0.0', '1643425395', '200', '2022', '0', '0');
INSERT INTO `mac_vlog` VALUES ('23', '324915', '高清', '腾讯视频', '0.0', '1643425404', '200', '1334', '0', '0');
INSERT INTO `mac_vlog` VALUES ('24', '324957', '高清', '腾讯视频', '0.0', '1643425427', '200', '13657', '0', '0');
INSERT INTO `mac_vlog` VALUES ('25', '266876', '预告', '优酷视频', '0.38', '1643426633', '200', '16466', '0', '0');
INSERT INTO `mac_vlog` VALUES ('58', '265052', '第29集', '腾讯视频', '0.96', '1643742813', '193', '2575825', '28', '0');
INSERT INTO `mac_vlog` VALUES ('62', '276690', '第1集', '芒果tv', '0.02', '1643732462', '193', '5377', '0', '0');
INSERT INTO `mac_vlog` VALUES ('73', '282123', '第1集', '优酷视频', '0.35', '1643781736', '194', '889546', '0', '0');
INSERT INTO `mac_vlog` VALUES ('74', '284196', '正片', '优酷视频', '0.0', '1643787938', '194', '3262', '0', '0');
INSERT INTO `mac_vlog` VALUES ('76', '279545', '第1集', '腾讯视频', '0.0', '1643805712', '194', '1995', '0', '0');
INSERT INTO `mac_vlog` VALUES ('44', '266872', '高清正片', '芒果tv', '0.0', '1643589998', '202', '14141', '0', '1');
INSERT INTO `mac_vlog` VALUES ('45', '260257', 'HD', '青豆片库', '0.0', '1643594000', '203', '6099', '0', '0');
INSERT INTO `mac_vlog` VALUES ('46', '260257', 'HD', '青豆片库', '0.01', '1643609044', '202', '45982', '0', '0');
INSERT INTO `mac_vlog` VALUES ('47', '339521', 'HD', '腾讯视频', '0.0', '1643609086', '202', '20764', '0', '0');
INSERT INTO `mac_vlog` VALUES ('48', '369533', '1集', '优酷视频', '0.02', '1643609302', '202', '42337', '0', '0');
INSERT INTO `mac_vlog` VALUES ('49', '282840', '正片', '腾讯视频', '0.0', '1643816055', '209', '241', '0', '0');
INSERT INTO `mac_vlog` VALUES ('50', '260257', 'HD', '青豆片库', '0.0', '1643713265', '193', '1986', '0', '0');
INSERT INTO `mac_vlog` VALUES ('51', '260297', '第1集', '腾讯视频', '0.0', '1643725990', '193', '3328', '0', '0');
INSERT INTO `mac_vlog` VALUES ('52', '260312', '第2集', '优酷视频', '0.0', '1643725980', '193', '4162', '1', '0');
INSERT INTO `mac_vlog` VALUES ('53', '283501', '正片', '腾讯视频', '0.02', '1643717844', '193', '94911', '0', '0');
INSERT INTO `mac_vlog` VALUES ('54', '282840', '正片', '腾讯视频', '0.0', '1643717854', '193', '2118', '0', '0');
INSERT INTO `mac_vlog` VALUES ('55', '286927', '英语高清正片', '优酷视频', '0.0', '1643717902', '193', '2017', '0', '0');
INSERT INTO `mac_vlog` VALUES ('56', '391014', '第1集', '奇艺视频', '0.01', '1643717916', '193', '3705', '0', '0');
INSERT INTO `mac_vlog` VALUES ('57', '283501', '正片', '腾讯视频', '0.0', '1643717976', '194', '2272', '0', '0');
INSERT INTO `mac_vlog` VALUES ('59', '286796', '正片', '优酷视频', '0.01', '1643719634', '194', '49830', '0', '0');
INSERT INTO `mac_vlog` VALUES ('60', '260429', '高清正片', '腾讯视频', '0.0', '1643729666', '193', '1972', '0', '0');
INSERT INTO `mac_vlog` VALUES ('61', '260369', '第01集', '青豆片库', '0.01', '1643731367', '194', '8046', '0', '0');
INSERT INTO `mac_vlog` VALUES ('63', '280462', '高清正片', '奇艺视频', '0.0', '1643732471', '193', '2453', '0', '0');
INSERT INTO `mac_vlog` VALUES ('64', '275434', '高清正片', '奇艺视频', '0.0', '1643732480', '193', '1121', '0', '0');
INSERT INTO `mac_vlog` VALUES ('65', '283583', '英语正片', '腾讯视频', '0.0', '1643732489', '193', '1098', '0', '0');
INSERT INTO `mac_vlog` VALUES ('66', '260311', '第1集', '腾讯视频', '0.0', '1643732505', '193', '2617', '0', '0');
INSERT INTO `mac_vlog` VALUES ('67', '283583', '英语正片', '腾讯视频', '0.51', '1643741012', '198', '3486879', '0', '0');
INSERT INTO `mac_vlog` VALUES ('68', '281606', '双语字幕正片', '腾讯视频', '0.0', '1643767931', '193', '1181', '0', '0');
INSERT INTO `mac_vlog` VALUES ('69', '279969', 'HD', '奇艺视频', '0.0', '1643767944', '193', '3164', '0', '0');
INSERT INTO `mac_vlog` VALUES ('70', '282123', '第1集', '优酷视频', '0.03', '1643768029', '193', '71933', '0', '0');
INSERT INTO `mac_vlog` VALUES ('71', '260313', '第2集', '腾讯视频', '0.0', '1643769748', '200', '688', '1', '0');
INSERT INTO `mac_vlog` VALUES ('72', '264325', 'HD1280高清中字版', '青豆片库', '0.5', '1643771441', '194', '3598961', '0', '0');
INSERT INTO `mac_vlog` VALUES ('101', '283583', '英语正片', '腾讯视频', '0.0', '1643822908', '216', '2043', '0', '0');
INSERT INTO `mac_vlog` VALUES ('80', '284044', '正片', '腾讯视频', '0.0', '1643816017', '209', '8768', '0', '0');
INSERT INTO `mac_vlog` VALUES ('81', '280798', '正片', '腾讯视频', '0.0', '1643816365', '209', '4682', '0', '0');
INSERT INTO `mac_vlog` VALUES ('82', '279969', 'HD', '奇艺视频', '0.0', '1643816382', '209', '8266', '0', '0');
INSERT INTO `mac_vlog` VALUES ('83', '260297', '第1集', '腾讯视频', '0.01', '1643817943', '209', '24839', '0', '0');
INSERT INTO `mac_vlog` VALUES ('84', '265052', '第1集', '腾讯视频', '0.29', '1643816863', '209', '790391', '0', '0');
INSERT INTO `mac_vlog` VALUES ('85', '284164', '第1集', '腾讯视频', '0.0', '1643818551', '209', '5195', '0', '0');
INSERT INTO `mac_vlog` VALUES ('86', '260312', '第1集', '优酷视频', '0.0', '1643816541', '209', '2594', '0', '0');
INSERT INTO `mac_vlog` VALUES ('87', '284148', '第1集', '腾讯视频', '0.01', '1643817967', '209', '19991', '0', '0');
INSERT INTO `mac_vlog` VALUES ('88', '279545', '第1集', '腾讯视频', '0.02', '1643816954', '209', '29448', '0', '0');
INSERT INTO `mac_vlog` VALUES ('89', '283820', '第1集', '腾讯视频', '0.06', '1643817050', '209', '92930', '0', '0');
INSERT INTO `mac_vlog` VALUES ('90', '278778', '高清正片', '奇艺视频', '0.0', '1643817060', '209', '1222', '0', '0');
INSERT INTO `mac_vlog` VALUES ('91', '260422', '第1集', '腾讯视频', '0.03', '1643817207', '209', '74804', '0', '0');
INSERT INTO `mac_vlog` VALUES ('92', '279969', 'HD', '奇艺视频', '0.0', '1643817200', '194', '8793', '0', '0');
INSERT INTO `mac_vlog` VALUES ('95', '283583', '英语正片', '腾讯视频', '0.0', '1643818011', '209', '3852', '0', '0');
INSERT INTO `mac_vlog` VALUES ('96', '280617', '第2020-08-16期', '腾讯视频', '0.0', '1643818027', '209', '5891', '0', '0');
INSERT INTO `mac_vlog` VALUES ('97', '280462', '高清正片', '奇艺视频', '0.03', '1643818164', '209', '133804', '0', '0');
INSERT INTO `mac_vlog` VALUES ('98', '282047', '第1集', '优酷视频', '0.0', '1643818196', '209', '7428', '0', '0');
INSERT INTO `mac_vlog` VALUES ('99', '282046', '第1集', '优酷视频', '0.14', '1643818542', '209', '339559', '0', '0');
INSERT INTO `mac_vlog` VALUES ('102', '282840', '正片', '腾讯视频', '0.0', '1643826259', '216', '340', '0', '0');
INSERT INTO `mac_vlog` VALUES ('103', '281606', '双语字幕正片', '腾讯视频', '0.0', '1643826254', '216', '223', '0', '0');
INSERT INTO `mac_vlog` VALUES ('104', '260884', '第1集', '奇艺视频', '0.0', '1643831841', '217', '2524', '0', '0');
INSERT INTO `mac_vlog` VALUES ('105', '266876', '高清正片', '优酷视频', '0.27', '1643831887', '217', '1309520', '0', '0');
INSERT INTO `mac_vlog` VALUES ('106', '266113', '2022-01-26期', '腾讯视频', '0.01', '1643831950', '217', '15674', '0', '0');
INSERT INTO `mac_vlog` VALUES ('107', '282337', '国语正片', '优酷视频', '0.0', '1643832004', '217', '2730', '0', '0');
INSERT INTO `mac_vlog` VALUES ('108', '339353', 'HD', '奇艺视频', '0.18', '1643832225', '217', '904207', '0', '0');
INSERT INTO `mac_vlog` VALUES ('109', '260297', '第01集', '青豆片库', '0.0', '1643836169', '218', '8345', '0', '3');
INSERT INTO `mac_vlog` VALUES ('110', '280462', '高清正片', '奇艺视频', '0.01', '1643858446', '220', '34846', '0', '0');
INSERT INTO `mac_vlog` VALUES ('111', '266876', '高清正片', '优酷视频', '0.0', '1643863196', '220', '19364', '0', '0');
INSERT INTO `mac_vlog` VALUES ('112', '391283', '2021-12-09', '奇艺视频', '0.0', '1644237260', '221', '8963', '0', '0');
INSERT INTO `mac_vlog` VALUES ('113', '391983', '第1集', '腾讯', '0.0', '1644237635', '222', '1620', '0', '0');
INSERT INTO `mac_vlog` VALUES ('114', '391976', '2020-07-22期', '腾讯', '0.0', '1644237672', '222', '913', '0', '0');
INSERT INTO `mac_vlog` VALUES ('115', '391839', '第1集', '腾讯', '0.0', '1644237676', '222', '919', '0', '0');
INSERT INTO `mac_vlog` VALUES ('116', '425885', '第1集', '腾讯', '0.0', '1644246026', '222', '1164', '0', '0');
INSERT INTO `mac_vlog` VALUES ('117', '425685', '正片', '腾讯', '0.0', '1644246031', '222', '680', '0', '0');
INSERT INTO `mac_vlog` VALUES ('118', '425643', '第1集', '腾讯', '0.0', '1644248701', '222', '1020', '0', '0');
INSERT INTO `mac_vlog` VALUES ('119', '424653', '第1集', '腾讯', '0.01', '1644299558', '223', '13449', '0', '0');
INSERT INTO `mac_vlog` VALUES ('120', '391716', '高清正片', '芒果视频', '0.0', '1644248067', '222', '1761', '0', '0');
INSERT INTO `mac_vlog` VALUES ('121', '425885', '第1集', '腾讯', '0.11', '1644299554', '223', '51411', '0', '0');
INSERT INTO `mac_vlog` VALUES ('122', '391567', 'HD', '芒果视频', '0.0', '1644248198', '222', '12018', '0', '1');
INSERT INTO `mac_vlog` VALUES ('123', '426023', '高清', '腾讯', '0.0', '1644248053', '222', '1796', '0', '0');
INSERT INTO `mac_vlog` VALUES ('124', '426165', '高清', '腾讯', '0.0', '1644248072', '222', '1110', '0', '0');
INSERT INTO `mac_vlog` VALUES ('125', '391944', '第1集', '奇艺视频', '0.0', '1644248162', '222', '328', '0', '0');
INSERT INTO `mac_vlog` VALUES ('126', '420093', '第1集', '腾讯', '0.01', '1644249782', '223', '23776', '0', '0');
INSERT INTO `mac_vlog` VALUES ('127', '391747', '第1集', '腾讯', '0.0', '1644248690', '222', '1511', '0', '0');
INSERT INTO `mac_vlog` VALUES ('128', '391361', '第1集', '优酷视频', '0.01', '1644248773', '225', '843', '0', '0');
INSERT INTO `mac_vlog` VALUES ('129', '391968', '2022-01-31期', '奇艺视频', '0.05', '1644248864', '225', '80172', '0', '0');
INSERT INTO `mac_vlog` VALUES ('130', '425682', '正片', '腾讯', '0.11', '1644249526', '226', '537557', '0', '0');
INSERT INTO `mac_vlog` VALUES ('131', '391968', '2022-01-31期', '奇艺视频', '0.01', '1644250946', '221', '9698', '0', '0');
INSERT INTO `mac_vlog` VALUES ('132', '425886', '第2017-10-07期', '腾讯', '0.0', '1644250953', '221', '2730', '0', '0');
INSERT INTO `mac_vlog` VALUES ('133', '425885', '第1集', '腾讯', '0.03', '1644297457', '227', '15131', '0', '0');
INSERT INTO `mac_vlog` VALUES ('134', '425682', '正片', '腾讯', '0.0', '1644251744', '228', '789', '0', '0');
INSERT INTO `mac_vlog` VALUES ('135', '425673', '第2集', '腾讯', '0.0', '1644254344', '229', '7160', '1', '0');
INSERT INTO `mac_vlog` VALUES ('136', '425695', '第4集', '腾讯', '0.01', '1644254759', '230', '2045', '3', '0');
INSERT INTO `mac_vlog` VALUES ('137', '391867', '英语高清正片', '优酷视频', '0.71', '1644254873', '230', '3729395', '0', '0');
INSERT INTO `mac_vlog` VALUES ('138', '391555', '英语正片', '腾讯', '0.56', '1644254916', '230', '5065470', '0', '0');
INSERT INTO `mac_vlog` VALUES ('139', '426159', '第1集', '腾讯', '0.0', '1644256779', '231', '6221', '0', '0');
INSERT INTO `mac_vlog` VALUES ('140', '391867', '英语高清正片', '优酷视频', '0.0', '1644271663', '233', '12257', '0', '0');
INSERT INTO `mac_vlog` VALUES ('141', '391561', '高清正片', '奇艺视频', '0.0', '1644285655', '228', '1855', '0', '2');
INSERT INTO `mac_vlog` VALUES ('142', '406483', 'HD', '腾讯', '0.0', '1644285663', '228', '3167', '0', '0');
INSERT INTO `mac_vlog` VALUES ('143', '422701', '正片', '腾讯', '0.0', '1644287496', '234', '1682', '0', '0');
INSERT INTO `mac_vlog` VALUES ('144', '425885', '第1集', '腾讯', '0.01', '1644287642', '235', '2474', '0', '0');
INSERT INTO `mac_vlog` VALUES ('145', '391567', 'HD', '芒果视频', '0.18', '1644300282', '235', '1062155', '0', '1');
INSERT INTO `mac_vlog` VALUES ('146', '391567', '高清正片', '腾讯', '0.01', '1644292836', '236', '78285', '0', '0');
INSERT INTO `mac_vlog` VALUES ('147', '391867', '英语高清正片', '优酷视频', '0.0', '1644295141', '237', '10049', '0', '0');
INSERT INTO `mac_vlog` VALUES ('148', '391910', '第1集', '奇艺视频', '0.24', '1644295254', '237', '85400', '0', '0');
INSERT INTO `mac_vlog` VALUES ('149', '420666', '第1集', '腾讯', '0.65', '1644296342', '237', '927818', '0', '0');
INSERT INTO `mac_vlog` VALUES ('150', '422784', '第1集', '腾讯', '0.27', '1644296371', '237', '300493', '0', '0');
INSERT INTO `mac_vlog` VALUES ('151', '391567', '高清正片', '腾讯', '0.0', '1644297477', '227', '9637', '0', '0');
INSERT INTO `mac_vlog` VALUES ('152', '425685', '正片', '腾讯', '0.0', '1644299563', '223', '265', '0', '0');
INSERT INTO `mac_vlog` VALUES ('153', '425682', '正片', '腾讯', '0.0', '1644299625', '223', '8008', '0', '0');
INSERT INTO `mac_vlog` VALUES ('154', '391968', '2022-01-31期', '奇艺视频', '0.0', '1644299671', '223', '6130', '0', '0');
INSERT INTO `mac_vlog` VALUES ('155', '426152', '第1集', '腾讯', '0.0', '1644300109', '223', '4108', '0', '0');
INSERT INTO `mac_vlog` VALUES ('156', '425986', '第1集', '腾讯', '0.0', '1644300154', '223', '171', '0', '0');
INSERT INTO `mac_vlog` VALUES ('157', '425948', '第1集', '腾讯', '0.05', '1644300307', '223', '146811', '0', '0');
INSERT INTO `mac_vlog` VALUES ('158', '391716', '高清正片', '芒果视频', '0.41', '1644507870', '238', '2887591', '0', '0');
INSERT INTO `mac_vlog` VALUES ('159', '425685', '正片', '腾讯', '0.47', '1644553235', '238', '3234144', '0', '0');
INSERT INTO `mac_vlog` VALUES ('160', '391747', '第2集', '腾讯', '0.23', '1644502137', '238', '292545', '1', '0');
INSERT INTO `mac_vlog` VALUES ('161', '391561', '普通话版', '腾讯', '0.33', '1644553200', '238', '2202550', '0', '2');
INSERT INTO `mac_vlog` VALUES ('163', '391561', '国语高清正片', '优酷视频', '0.0', '1644486807', '239', '5345', '0', '0');
INSERT INTO `mac_vlog` VALUES ('164', '391747', '第1集', '腾讯', '0.0', '1644488116', '242', '11', '0', '0');
INSERT INTO `mac_vlog` VALUES ('165', '391561', '国语高清正片', '优酷视频', '0.26', '1644488917', '241', '1748143', '0', '0');
INSERT INTO `mac_vlog` VALUES ('166', '391716', 'HD', '奇艺视频', '0.0', '1644488971', '241', '2286', '0', '3');
INSERT INTO `mac_vlog` VALUES ('190', '391196', '第1集', '腾讯', '0.27', '1644553635', '238', '722408', '0', '0');
INSERT INTO `mac_vlog` VALUES ('191', '440460', '第1集', '芒果视频', '0.0', '1644553760', '238', '12391', '0', '0');
INSERT INTO `mac_vlog` VALUES ('170', '391567', '正片', '红牛在线', '0.07', '1644506235', '238', '422814', '0', '1');
INSERT INTO `mac_vlog` VALUES ('193', '391602', '第1集', '奇艺视频', '0.03', '1644553985', '238', '79979', '0', '1');
INSERT INTO `mac_vlog` VALUES ('173', '425682', '正片', '腾讯', '0.0', '1644492176', '238', '1364', '0', '0');
INSERT INTO `mac_vlog` VALUES ('181', '422901', '正片', '腾讯', '0.0', '1644506124', '238', '9305', '0', '0');
INSERT INTO `mac_vlog` VALUES ('174', '391567', 'HD', '奇艺视频', '0.0', '1644498373', '241', '1673', '0', '4');
INSERT INTO `mac_vlog` VALUES ('175', '425986', '第1集', '腾讯', '0.0', '1644498393', '241', '1268', '0', '0');
INSERT INTO `mac_vlog` VALUES ('176', '426166', '正片', '红牛在线', '0.96', '1644517123', '238', '8084931', '0', '0');
INSERT INTO `mac_vlog` VALUES ('177', '391182', '第01集', '红牛在线', '0.35', '1644500303', '238', '944780', '0', '0');
INSERT INTO `mac_vlog` VALUES ('178', '426167', '高清', '红牛在线', '0.0', '1644506880', '238', '35123', '0', '0');
INSERT INTO `mac_vlog` VALUES ('179', '426168', '高清', '红牛在线', '0.0', '1644500600', '243', '9081', '0', '0');
INSERT INTO `mac_vlog` VALUES ('180', '426173', '高清', '红牛在线', '0.0', '1644500866', '238', '20040', '0', '0');
INSERT INTO `mac_vlog` VALUES ('182', '421487', 'HD高清', '红牛在线', '0.15', '1644507900', '238', '826899', '0', '0');
INSERT INTO `mac_vlog` VALUES ('183', '422720', '正片', '红牛在线', '0.33', '1644518198', '243', '1629521', '0', '0');
INSERT INTO `mac_vlog` VALUES ('184', '422203', 'HD高清', '红牛在线', '0.0', '1644541503', '238', '17513', '0', '0');
INSERT INTO `mac_vlog` VALUES ('185', '391747', '第1集', '腾讯', '0.78', '1644547987', '229', '914925', '0', '1');
INSERT INTO `mac_vlog` VALUES ('186', '391579', '清晰版', '红牛在线', '0.8', '1644548266', '229', '6735333', '0', '0');
INSERT INTO `mac_vlog` VALUES ('187', '391550', 'HD', '腾讯', '0.03', '1644553226', '238', '14905', '0', '0');
INSERT INTO `mac_vlog` VALUES ('188', '391510', '第2集', '奇艺视频', '0.46', '1644553533', '238', '196535', '1', '0');
INSERT INTO `mac_vlog` VALUES ('189', '425643', '第1集', '腾讯', '0.0', '1644553565', '238', '1672', '0', '0');
INSERT INTO `mac_vlog` VALUES ('192', '440513', '第1集', '芒果视频', '0.0', '1644553886', '238', '111', '0', '0');

-- -----------------------------
-- Table structure for `mac_website`
-- -----------------------------
DROP TABLE IF EXISTS `mac_website`;
CREATE TABLE `mac_website` (
  `website_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `type_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `website_name` varchar(60) NOT NULL DEFAULT '',
  `website_sub` varchar(255) NOT NULL DEFAULT '',
  `website_en` varchar(255) NOT NULL DEFAULT '',
  `website_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `website_letter` char(1) NOT NULL DEFAULT '',
  `website_color` varchar(6) NOT NULL DEFAULT '',
  `website_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `website_sort` int(10) NOT NULL DEFAULT '0',
  `website_jumpurl` varchar(255) NOT NULL DEFAULT '',
  `website_pic` varchar(255) NOT NULL DEFAULT '',
  `website_logo` varchar(255) NOT NULL DEFAULT '',
  `website_area` varchar(20) NOT NULL DEFAULT '',
  `website_lang` varchar(10) NOT NULL DEFAULT '',
  `website_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `website_time` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `website_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `website_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_tag` varchar(100) NOT NULL DEFAULT '',
  `website_class` varchar(255) NOT NULL DEFAULT '',
  `website_remarks` varchar(100) NOT NULL DEFAULT '',
  `website_tpl` varchar(30) NOT NULL DEFAULT '',
  `website_blurb` varchar(255) NOT NULL DEFAULT '',
  `website_content` mediumtext NOT NULL,
  PRIMARY KEY (`website_id`),
  KEY `type_id` (`type_id`),
  KEY `type_id_1` (`type_id_1`),
  KEY `website_name` (`website_name`),
  KEY `website_en` (`website_en`),
  KEY `website_letter` (`website_letter`),
  KEY `website_sort` (`website_sort`),
  KEY `website_lock` (`website_lock`),
  KEY `website_time` (`website_time`),
  KEY `website_time_add` (`website_time_add`),
  KEY `website_hits` (`website_hits`),
  KEY `website_hits_day` (`website_hits_day`),
  KEY `website_hits_week` (`website_hits_week`),
  KEY `website_hits_month` (`website_hits_month`),
  KEY `website_time_make` (`website_time_make`),
  KEY `website_score` (`website_score`),
  KEY `website_score_all` (`website_score_all`),
  KEY `website_score_num` (`website_score_num`),
  KEY `website_up` (`website_up`),
  KEY `website_down` (`website_down`),
  KEY `website_level` (`website_level`),
  KEY `website_tag` (`website_tag`),
  KEY `website_class` (`website_class`),
  KEY `website_referer` (`website_referer`),
  KEY `website_referer_day` (`website_referer_day`),
  KEY `website_referer_week` (`website_referer_week`),
  KEY `website_referer_month` (`website_referer_month`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_youxi`
-- -----------------------------
DROP TABLE IF EXISTS `mac_youxi`;
CREATE TABLE `mac_youxi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `img` varchar(500) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='APP游戏页面';

-- -----------------------------
-- Records of `mac_youxi`
-- -----------------------------
INSERT INTO `mac_youxi` VALUES ('1', '游戏', '1', 'http://www.cninfo.com.cn/new/index');

-- -----------------------------
-- Table structure for `mac_zhibo`
-- -----------------------------
DROP TABLE IF EXISTS `mac_zhibo`;
CREATE TABLE `mac_zhibo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `img` varchar(500) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='直播';

-- -----------------------------
-- Records of `mac_zhibo`
-- -----------------------------
INSERT INTO `mac_zhibo` VALUES ('1', '虎牙电影轮播', 'http://img3.imgtn.bdimg.com/it/u=4071645708,1806944269&fm=26&gp=0.jpg', 'https://m.huya.com/g/2135?rso=huya_h5_395');
INSERT INTO `mac_zhibo` VALUES ('2', '网络电视直播', 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=820960115,2542239298&fm=26&gp=0.jpg', 'http://www.zhiboba.org/dianshitai/');
INSERT INTO `mac_zhibo` VALUES ('3', '战旗游戏直播', 'http://img5.imgtn.bdimg.com/it/u=2222041607,2096500012&fm=26&gp=0.jpg', 'https://m.zhanqi.tv/lives');
INSERT INTO `mac_zhibo` VALUES ('4', '游拍直播', 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2274747463,4183354344&fm=26&gp=0.jpg', 'https://m.4399youpai.com/zhibo/game/');
INSERT INTO `mac_zhibo` VALUES ('5', '股票期货直播', 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=537084912,2581552393&fm=26&gp=0.jpg', 'http://www.1234tv.com/');
INSERT INTO `mac_zhibo` VALUES ('6', '6房间美女直播', 'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2025620803,4212504364&fm=26&gp=0.jpg', 'http://m.v.6.cn/?referrer=');
INSERT INTO `mac_zhibo` VALUES ('7', '虎牙游戏直播', 'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2866237030,2397668445&fm=26&gp=0.jpg', 'https://www.huya.com/g');
INSERT INTO `mac_zhibo` VALUES ('8', '电视剧', 'https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2102833997,2917410739&fm=26&gp=0.jpg', 'http://jx2.tcspvip.com/pangu/?url=https://files.catbox.moe/f5vaox.m3u8');
INSERT INTO `mac_zhibo` VALUES ('9', '微赞', 'http://img4.imgtn.bdimg.com/it/u=628053479,3428469491&fm=26&gp=0.jpg', 'https://wx.vzan.com/live/tvchat-70010603#/');
INSERT INTO `mac_zhibo` VALUES ('10', '音乐', 'http://img2.imgtn.bdimg.com/it/u=2059116237,2535882687&fm=26&gp=0.jpg', 'http://tcspvip.cn/music/');

-- -----------------------------
-- Table structure for `mac_admin`
-- -----------------------------
DROP TABLE IF EXISTS `mac_admin`;
CREATE TABLE `mac_admin` (
  `admin_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(30) NOT NULL DEFAULT '',
  `admin_pwd` char(32) NOT NULL DEFAULT '',
  `admin_random` char(32) NOT NULL DEFAULT '',
  `admin_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `admin_auth` text NOT NULL,
  `admin_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_login_num` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_last_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`admin_id`) USING BTREE,
  KEY `admin_name` (`admin_name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员账户';

-- -----------------------------
-- Records of `mac_admin`
-- -----------------------------
INSERT INTO `mac_admin` VALUES ('1', '79581008', '614c95d7a9cc61c2525b9f3f19aa396b', '9fae9d2c125737489a06049999a4bda8', '1', ',index/welcome,index/quickmenu,index/iframe,index/clear,index/unlocked,index/select,upload/upload,system/config,system/configcomment,system/configupload,system/configurl,system/configplay,system/configcollect,system/configinterface,system/configapi,system/configconnect,system/configweixin,system/configemail,timming/index,type/info,type/del,type/field,type/index,type/info,type/batch,type/del,type/field,type/extend,topic/data,topic/info,topic/batch,topic/del,topic/field,link/index,link/info,link/batch,link/del,link/field,gbook/data,gbook/info,gbook/del,gbook/field,comment/data,comment/info,comment/del,comment/field,images/index,images/del,category/index,category/info,category/del,category/field,vodplayer/index,vodplayer/info,vodplayer/del,vodplayer/field,role/data,role/info,role/del,role/field,role/info,vod/data,vod/info,vod/del,vod/field,vod/info,vod/data,vod/data,vod/data,vod/data,vod/batch,vod/data,vodserver/index,vodserver/info,vodserver/del,vodserver/field,voddowner/index,voddowner/info,voddowner/del,voddowner/field,actor/data,actor/info,actor/del,actor/field,actor/info,art/data,art/info,art/del,art/field,art/info,art/data,art/data,art/batch,art/data,admin/index,admin/info,admin/del,admin/field,group/index,group/info,group/del,group/field,user/data,user/info,user/del,user/field,card/index,card/info,card/del,order/index,order/del,ulog/index,ulog/del,plog/index,plog/del,glog/index,cash/index,cash/del,cash/audit,template/index,template/info,template/del,template/ads,template/wizard,collect/index,collect/info,collect/del,cj/index,cj/info,cj/del,cj/program,cj/col_url,cj/col_content,cj/publish,cj/export,cj/import,database/index,database/export,database/import,database/optimize,database/repair,database/del,database/columns,database/sql,database/rep,system/configuser,system/configsms,system/configapppopupwindow,system/configtaskarticle,appversion/index,appsetting/index,system/configpay,adtype/index,adtype/info,adtype/del,adtype/field,zhibo/index,youxi/index,message/index,message/info,message/del,message/field,groupchat/index,groupchat/info,groupchat/del,groupchat/field,wxapi/info,wxapi/del,wxapi/field,admin/lock,addon/index,urlsend/index,urlsend/push,urlsend/baidu_push,urlsend/baidu_bear,addon/downloaded,addon/install,addon/uninstall,addon/config,addon/state,addon/local,addon/upgrade,', '1644551227', '1946443472', '1603', '1644550669', '1946443472');
