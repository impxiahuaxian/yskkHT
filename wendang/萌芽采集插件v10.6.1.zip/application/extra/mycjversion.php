<?php
return array (
    'name' => '萌芽采集插件',
    'copyright' => 'Mycj',
    'url' => 'https://plug.vrecf.com/',
    'code' => 'v10.6.1',
);
?>